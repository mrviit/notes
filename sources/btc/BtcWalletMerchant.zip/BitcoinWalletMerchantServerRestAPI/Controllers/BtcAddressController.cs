﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BitcoinWalletMerchantServerRestAPI.Models;
using BitcoinWalletMerchantServerRestAPI.Utils;
using Microsoft.AspNetCore.Mvc;
using NBitcoin;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BitcoinWalletMerchantServerRestAPI.Controllers
{
    [Route("api/[controller]")]
    public class BtcAddressController : Controller
    {
        private readonly BtcAddressContext _context;

        public BtcAddressController(BtcAddressContext context)
        {
            _context = context;

            //if (_context.BtcAddresses.Count() == 0)
            //{
            //    _context.BtcAddresses.Add(new BtcAddress {
            //        Address = BtcFacade.GenerateNewAddress().PubKey.GetAddress(Network.TestNet).ToString() });
            //    _context.SaveChanges();
            //}
        }

        // GET: api/<controller>
        [HttpGet]
        public IEnumerable<BtcAddress> GetAll()
        {
            return _context.BtcAddresses.ToList();
        }

        // GET api/<controller>/5
        [HttpGet("{id}", Name = "GetBtcAddress")]
        public IActionResult GetById(int id)
        {
            var item = _context.BtcAddresses.FirstOrDefault(t => t.Id == id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }

        /// <summary>
        /// Creates a BtcAddress.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /BtcAddress
        ///     {
        ///        "id": 1,
        ///        "address": "btcAddress",
        ///        "isComplete": true
        ///     }
        ///
        /// </remarks>
        /// <param name="item"></param>
        /// <returns>A newly-created TodoItem</returns>
        /// <response code="201">Returns the newly-created item</response>
        /// <response code="400">If the item is null</response>            
        [HttpPost]
        [ProducesResponseType(typeof(BtcAddress), 201)]
        [ProducesResponseType(typeof(BtcAddress), 400)]
        public IActionResult Create([FromBody] BtcAddress item)
        {
            if (item == null)
            {
                return BadRequest();
            }

            _context.BtcAddresses.Add(item);
            _context.SaveChanges();

            return CreatedAtRoute("GetBtcAddress", new { id = item.Id }, item);
        }

        // PUT api/<controller>/5
        [HttpPut("{id}")]
        public IActionResult Update(long id, [FromBody] BtcAddress item)
        {
            if (item == null || item.Id != id)
            {
                return BadRequest();
            }

            var btcAddress = _context.BtcAddresses.FirstOrDefault(t => t.Id == id);
            if (btcAddress == null)
            {
                return NotFound();
            }

            btcAddress.IsComplete = item.IsComplete;
            btcAddress.Address = item.Address;

            _context.BtcAddresses.Update(btcAddress);
            _context.SaveChanges();
            return new NoContentResult();
        }

        /// <summary>
        /// Deletes a specific BtcAddress.
        /// </summary>
        /// <param name="id"></param>     
        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            var btcAddress = _context.BtcAddresses.FirstOrDefault(t => t.Id == id);
            if (btcAddress == null)
            {
                return NotFound();
            }

            _context.BtcAddresses.Remove(btcAddress);
            _context.SaveChanges();
            return new NoContentResult();
        }
    }
}
