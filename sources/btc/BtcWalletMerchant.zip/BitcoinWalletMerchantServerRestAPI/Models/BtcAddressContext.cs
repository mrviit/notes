﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BitcoinWalletMerchantServerRestAPI.Models
{
    public class BtcAddressContext : DbContext
    {
        public BtcAddressContext(DbContextOptions<BtcAddressContext> options)
            : base(options)
        {
        }

        public DbSet<BtcAddress> BtcAddresses { get; set; }
    }
}
