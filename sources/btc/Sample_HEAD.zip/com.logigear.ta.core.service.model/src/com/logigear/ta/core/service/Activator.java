package com.logigear.ta.core.service;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import com.logigear.ta.core.service.model.IProjectService;
import com.logigear.ta.core.service.model.internal.ProjectService;

public class Activator implements BundleActivator {

	@Override
	public void start(BundleContext bundleContext) throws Exception {
		bundleContext.registerService(IProjectService.class, new ProjectService(), null);
	}

	@Override
	public void stop(BundleContext bundleContext) throws Exception {
		// TODO Auto-generated method stub

	}

}
