package com.logigear.ta.core.service.model;

import java.io.File;

import com.logigear.ta.core.model.Project;

public interface IProjectService {
	
	Project build(File projectFile);

}
