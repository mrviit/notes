package com.logigear.ta.core.service.model.internal;

import java.io.File;

import com.logigear.ta.core.model.DatasetRoot;
import com.logigear.ta.core.model.InterfaceRoot;
import com.logigear.ta.core.model.Project;
import com.logigear.ta.core.model.ProjectConfiguration;
import com.logigear.ta.core.model.TestRoot;
import com.logigear.ta.core.model.internal.DatasetRootImpl;
import com.logigear.ta.core.model.internal.InterfaceRootImpl;
import com.logigear.ta.core.model.internal.ProjectConfigurationImpl;
import com.logigear.ta.core.model.internal.ProjectImpl;
import com.logigear.ta.core.model.internal.TestRootImpl;
import com.logigear.ta.core.service.model.IProjectService;

public class ProjectService implements IProjectService {

	@Override
	public Project build(File projectFile) {
		Project project = new ProjectImpl("Car Rental");
		ProjectConfiguration projectConfiguration = new ProjectConfigurationImpl();
		TestRoot testRoot = new TestRootImpl("Tests", project, null);
		projectConfiguration.setTestRoot(testRoot);
//		ActionRoot actionRoot = new ActionRootImpl("Actions", project, null);
//		projectConfiguration.setActionRoot(actionRoot);
		DatasetRoot datasetRoot = new DatasetRootImpl("Data", project, null);
		projectConfiguration.setDatasetRoot(datasetRoot);
		InterfaceRoot interfaceRoot = new InterfaceRootImpl("Interfaces", project, null);
		projectConfiguration.setInterfaceRoot(interfaceRoot);
		project.setProjectConfiguration(projectConfiguration);
		return project;
	}
	
	

}
