package com.logigear.rcp.app.project_explorer.handlers;

import javax.inject.Inject;

import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IStructuredSelection;

import com.logigear.rcp.app.common.EventsTopic;
import com.logigear.ta.core.model.EntityPath;

public class OpenProjectItemHandler implements IDoubleClickListener {

	@Inject IEventBroker eventBroker;

	@Override
	public void doubleClick(DoubleClickEvent event) {
		final IStructuredSelection selection = (IStructuredSelection)event.getSelection();
	    if (selection == null || selection.size() != 1)
	      return;

	    final Object sel = selection.getFirstElement();
	    System.out.println("Selected item: " + sel.getClass());
	    if(sel instanceof EntityPath) {
	    	EntityPath item = (EntityPath)sel;
			
//			IEclipseContext staticContext = EclipseContextFactory.create();
//			IEclipseContext eclipseContext = E4Workbench.getServiceContext();
//			eventBroker = eclipseContext.get(IEventBroker.class);
			eventBroker.send(EventsTopic.OPEN_PROJECT_ITEM, item);
	    }
	}
}
