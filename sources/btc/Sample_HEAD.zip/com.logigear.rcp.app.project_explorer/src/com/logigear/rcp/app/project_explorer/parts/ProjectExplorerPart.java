package com.logigear.rcp.app.project_explorer.parts;

import com.logigear.rcp.app.common.EventsTopic;
import com.logigear.rcp.app.project_explorer.content_providers.ProjectExplorerContentProvider;
import com.logigear.rcp.app.project_explorer.content_providers.ProjectExplorerLabelProvider;
import com.logigear.rcp.app.project_explorer.handlers.ImportProjectEventHandler;
import com.logigear.rcp.app.project_explorer.handlers.OpenProjectItemHandler;
import javax.annotation.PostConstruct;
import org.eclipse.e4.core.contexts.ContextInjectionFactory;
import org.eclipse.e4.core.contexts.IEclipseContext;
import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;

public class ProjectExplorerPart {
	
	protected TreeViewer viewer;
	
	@PostConstruct
	public void createComposite(Composite parent, IEclipseContext context, IEventBroker eventBroker) {
		GridLayout layout = new GridLayout();
		layout.marginHeight = 0;
		layout.marginWidth = 0;
		parent.setLayout(layout);
		GridData data = new GridData(GridData.FILL_BOTH);
		data.grabExcessHorizontalSpace = true;
		data.grabExcessVerticalSpace = true;
		parent.setLayoutData(data);
		
		viewer = new TreeViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
		
		viewer.setContentProvider(new ProjectExplorerContentProvider());
		viewer.getTree().setLayoutData(new GridData(GridData.FILL_BOTH));
		
		ProjectExplorerLabelProvider labelProvider = ContextInjectionFactory.make(ProjectExplorerLabelProvider.class, context);
		viewer.setLabelProvider(labelProvider);
		
		OpenProjectItemHandler handler = ContextInjectionFactory.make(OpenProjectItemHandler.class, context);
		viewer.addDoubleClickListener(handler);
				
		eventBroker.subscribe(EventsTopic.IMPORT_PROJECT, new ImportProjectEventHandler(viewer));
	}
}
