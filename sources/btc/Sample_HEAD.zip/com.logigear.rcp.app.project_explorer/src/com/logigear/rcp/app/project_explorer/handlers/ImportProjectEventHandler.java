package com.logigear.rcp.app.project_explorer.handlers;

import com.logigear.ta.core.model.Project;
import com.logigear.ta.core.parsers.ProjectParser;
import com.logigear.ta.core.parsers.internal.ProjectParserImpl;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.jface.viewers.TreeViewer;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;

public class ImportProjectEventHandler implements EventHandler {
	
	private TreeViewer viewer;
	
	public ImportProjectEventHandler(TreeViewer viewer) {
		this.viewer = viewer;
	}

	@Override
	public void handleEvent(Event event) {
		System.out.println("Process event: " + event.getTopic());
		Object object = event.getProperty(IEventBroker.DATA);
		if(object != null && object instanceof Path) {
			Path path = (Path) object;
			ProjectParser projectParser = new ProjectParserImpl();
			Project project = projectParser.parse(path.getParent(), path.toFile().getName(), "project.config.json");
			List<Project> ps = new ArrayList<>();
			ps.add(project);
	        viewer.setInput(ps);
		}
		
	}
}
