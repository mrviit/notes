package com.logigear.rcp.app.project_explorer.content_providers;

import java.util.List;

import org.eclipse.jface.viewers.ITreeContentProvider;
import com.logigear.ta.core.model.Entity;

public class ProjectExplorerContentProvider implements ITreeContentProvider {
	
    @Override
    public Object[] getElements(Object inputElement) {

		if(inputElement instanceof Entity) {
			return ((Entity)inputElement).getChildren().toArray();
		} 
		if(inputElement instanceof List) {
			return ((List)inputElement).toArray();
		}
        return null;
    }

    @Override
    public Object[] getChildren(Object parentElement) {
		if (parentElement instanceof Entity) {
			return ((Entity)parentElement).getChildren().toArray();
		} else if((parentElement instanceof List)) {
            return ((List<?>) parentElement).toArray();
        }
        return null;
    }

    @Override
    public Object getParent(Object element) {
		if (element instanceof Entity) {
            return ((Entity) element).getParent();
        }
        return null;
    }

    @Override
    public boolean hasChildren(Object element) {
        if (element instanceof Entity) {
        	if(((Entity)element).getChildren() == null) {
        		return false;
        	}
            return !((Entity)element).getChildren().isEmpty();
        }
        return false;
    }

}