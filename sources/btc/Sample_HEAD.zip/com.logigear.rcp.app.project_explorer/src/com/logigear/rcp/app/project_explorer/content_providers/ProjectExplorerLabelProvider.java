package com.logigear.rcp.app.project_explorer.content_providers;

import javax.inject.Inject;

import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.swt.graphics.Image;

import com.logigear.ta.resources.IconService;

public class ProjectExplorerLabelProvider extends LabelProvider {

	@Inject
	IconService iconService;
	
	@Override
	public Image getImage(Object element) {
//		IEclipseContext eclipseContext = E4Workbench.getServiceContext();
//		iconService = eclipseContext.get(IconService.class);
		try {
			Image image = iconService.getImage(element.getClass());
			if (image != null) {
				return image;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return super.getImage(element);
	}
}