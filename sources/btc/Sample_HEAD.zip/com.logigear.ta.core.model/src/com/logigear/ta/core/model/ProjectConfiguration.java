package com.logigear.ta.core.model;

public interface ProjectConfiguration {	

	TestRoot getTestRoot();
	
	void setTestRoot(TestRoot testRoot);
	
	DatasetRoot getDataRoot();
	
	void setDatasetRoot(DatasetRoot datasetRoot);
	
	ActionRoot getActionRoot();
	
	void setActionRoot(ActionRoot actionRoot);
	
	InterfaceRoot getInterfaceRoot();
	
	void setInterfaceRoot(InterfaceRoot interfaceRoot);
	
	
}
