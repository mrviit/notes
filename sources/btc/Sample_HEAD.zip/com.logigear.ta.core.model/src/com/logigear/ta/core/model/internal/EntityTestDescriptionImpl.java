package com.logigear.ta.core.model.internal;

import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.EntityTest;

public abstract class EntityTestDescriptionImpl extends EntityDescriptionImpl implements EntityTest {

	private String id, title;
	
	public EntityTestDescriptionImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
		id = name;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}
}
