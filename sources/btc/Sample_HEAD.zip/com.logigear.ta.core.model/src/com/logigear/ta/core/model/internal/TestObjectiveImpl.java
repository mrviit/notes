package com.logigear.ta.core.model.internal;

import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestObjective;

public class TestObjectiveImpl extends EntityTestImpl implements TestObjective{
	
	private int testCoverages;

	public TestObjectiveImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
	}

	@Override
	public int getTestCoverages() {
		return testCoverages;
	}

	@Override
	public void setTestCoverages(int value) {
		this.testCoverages = value;
	}
}
