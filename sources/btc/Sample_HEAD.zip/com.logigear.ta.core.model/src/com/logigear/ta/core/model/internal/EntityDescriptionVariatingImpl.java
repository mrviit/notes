package com.logigear.ta.core.model.internal;

import com.logigear.ta.core.model.EntityDescriptionVariating;

import java.util.List;

import com.logigear.ta.core.model.Entity;

public abstract class EntityDescriptionVariatingImpl extends EntityImpl implements  EntityDescriptionVariating {
	
	private String description;

	public EntityDescriptionVariatingImpl(Entity parent) {
		super(null, parent, null);
	}
	
	public EntityDescriptionVariatingImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public void setDescription(String description) {
		this.description = description;
	}
}
