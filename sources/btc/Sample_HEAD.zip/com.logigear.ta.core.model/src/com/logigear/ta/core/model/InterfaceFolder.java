package com.logigear.ta.core.model;

import java.util.List;

public interface InterfaceFolder extends EntityFolder {

	List<InterfaceEntity> getInterfaceEntities(boolean isRecursive);

	List<InterfaceFolder> getInterfaceFolders(boolean isRecurvie);
	
	void addInterfaceEntity(InterfaceEntity interfaceEntity);
	
	void addInterfaceFolder(InterfaceFolder interfaceFolder);
	
	void setInterfaceEntities(List<InterfaceEntity> entities);
	void setInterfaceFolders(List<InterfaceFolder> interfaceFolders);
}
