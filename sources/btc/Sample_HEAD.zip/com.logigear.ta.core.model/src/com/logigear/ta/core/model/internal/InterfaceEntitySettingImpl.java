package com.logigear.ta.core.model.internal;

import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceEntitySetting;

public class InterfaceEntitySettingImpl extends EntityImpl implements InterfaceEntitySetting {

	private String name, value;
	
	public InterfaceEntitySettingImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	

}
