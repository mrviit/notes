package com.logigear.ta.core.model.internal;

import com.logigear.ta.core.model.EntityDescription;

import java.util.List;

import com.logigear.ta.core.model.Entity;

public abstract class EntityDescriptionImpl extends EntityImpl implements EntityDescription {
	
	private String description;

	public EntityDescriptionImpl(Entity parent) {
		super(null, parent, null);
	}
	
	public EntityDescriptionImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public void setDescription(String description) {
		this.description = description;
	}
}
