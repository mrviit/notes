package com.logigear.ta.core.model.internal;

import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestStep;

public class TestStepImpl extends EntityImpl implements TestStep {

	private String id, title, description, expected;

	public TestStepImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
		id = name;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public void setDescription(String description) {
		this.description = description;

	}

	@Override
	public String getExpected() {
		return expected;
	}

	@Override
	public void setExpected(String expected) {
		this.expected = expected;
	}
	
	@Override
	public String toString() {
		return getTitle();
	}
}
