package com.logigear.ta.core.model;

public interface EntityTestDescription extends EntityTest, EntityDescription {
}
