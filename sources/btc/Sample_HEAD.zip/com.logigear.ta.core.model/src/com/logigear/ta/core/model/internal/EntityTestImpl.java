package com.logigear.ta.core.model.internal;

import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.EntityTestDescription;

public abstract class EntityTestImpl extends EntityDescriptionImpl implements EntityTestDescription {

	private String id, title;
	
	public EntityTestImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
		id = name;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String getTitle() {
		return title;
	}

	@Override
	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public String toString() {		
		return getId() + ", " + getTitle();
	}
}
