package com.logigear.ta.core.model.internal;

import com.logigear.ta.core.model.ActionRoot;
import com.logigear.ta.core.model.DatasetRoot;
import com.logigear.ta.core.model.InterfaceRoot;
import com.logigear.ta.core.model.ProjectConfiguration;
import com.logigear.ta.core.model.TestRoot;

public class ProjectConfigurationImpl implements ProjectConfiguration {

	private TestRoot testRoot;
	private DatasetRoot datasetRoot;
	private ActionRoot actionRoot;
	private InterfaceRoot interfaceRoot;

	@Override
	public TestRoot getTestRoot() {
		return testRoot;
	}

	@Override
	public void setTestRoot(TestRoot testRoot) {
		this.testRoot = testRoot;
	}

	@Override
	public DatasetRoot getDataRoot() {
		return datasetRoot;
	}

	@Override
	public void setDatasetRoot(DatasetRoot datasetRoot) {
		this.datasetRoot = datasetRoot;

	}

	@Override
	public ActionRoot getActionRoot() {
		return actionRoot;
	}

	@Override
	public void setActionRoot(ActionRoot actionRoot) {
		this.actionRoot = actionRoot;
	}

	@Override
	public InterfaceRoot getInterfaceRoot() {
		return interfaceRoot;
	}

	@Override
	public void setInterfaceRoot(InterfaceRoot interfaceRoot) {
		this.interfaceRoot = interfaceRoot;
	}

}
