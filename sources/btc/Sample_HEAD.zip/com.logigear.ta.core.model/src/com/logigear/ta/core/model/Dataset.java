package com.logigear.ta.core.model;

import java.util.List;

public interface Dataset extends EntityVariating{
	
	List<String> getColumnNames();
	
	int getColumnCount();
	
	long getRowCount();

}
