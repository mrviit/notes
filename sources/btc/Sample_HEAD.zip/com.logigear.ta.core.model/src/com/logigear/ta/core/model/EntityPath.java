package com.logigear.ta.core.model;

import java.nio.file.Path;

public interface EntityPath extends Entity {
	
	Path getPath();	
	void setPath(Path path);
	
}
