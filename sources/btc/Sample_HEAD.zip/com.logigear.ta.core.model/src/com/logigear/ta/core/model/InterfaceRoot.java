package com.logigear.ta.core.model;

import java.nio.file.Path;
import java.util.List;

public interface InterfaceRoot extends Entity {

	Path getPath();

	void setPath(Path path);

	List<Interface> getInterfaces();

	void addInterface(Interface interface1);
	
	String getDefaultInterfaceName();
}
