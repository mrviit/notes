package com.logigear.ta.core.model;

import java.util.List;

public interface TestFolder extends EntityFolder {
	
	List<TestModule> getTestModules(boolean isRecursive);
	
	List<TestFolder> getTestFolders(boolean isRecursive);
	
	void setTestModules(List<TestModule> testModules);
	void addTestModule(TestModule testModule);
	void addTestModules(List<TestModule> testModules);

	void setTestFolders(List<TestFolder> testFolders);
	void addTestFolder(TestFolder testFolder);
	void addTestFolders(List<TestFolder> testFolders);
}
