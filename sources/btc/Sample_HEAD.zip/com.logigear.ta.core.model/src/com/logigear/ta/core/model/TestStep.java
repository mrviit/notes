package com.logigear.ta.core.model;

public interface TestStep extends Entity{
	
	String getId();	
	void setId(String id);
	
	String getTitle();	
	void setTitle(String title);
	
	String getDescription();	
	void setDescription(String description);
	
	String getExpected();	
	void setExpected(String expected);
}
