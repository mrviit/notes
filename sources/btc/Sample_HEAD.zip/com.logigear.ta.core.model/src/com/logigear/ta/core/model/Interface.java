package com.logigear.ta.core.model;

public interface Interface extends InterfaceFolder {

	boolean isDefault();

	void setDefaultInterface(boolean isDefault);

}
