package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceEntity;
import com.logigear.ta.core.model.InterfaceFolder;

public class InterfaceFolderImpl extends EntityFolderImpl implements InterfaceFolder {

	private List<InterfaceFolder> interfaceFolders = new ArrayList<InterfaceFolder>();
	private List<InterfaceEntity> interfaceEntities = new ArrayList<InterfaceEntity>();
	
	public InterfaceFolderImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}
	
	public InterfaceFolderImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}

	@Override
	public List<InterfaceEntity> getInterfaceEntities(boolean isRecursive) {
		return interfaceEntities;
	}

	@Override
	public List<InterfaceFolder> getInterfaceFolders(boolean isRecurvie) {
		return interfaceFolders;
	}

	@Override
	public void addInterfaceEntity(InterfaceEntity interfaceEntity) {
		interfaceEntities.add(interfaceEntity);
		addChild(interfaceEntity);
	}

	@Override
	public void addInterfaceFolder(InterfaceFolder interfaceFolder) {
		interfaceFolders.add(interfaceFolder);
		addChild(interfaceFolder);
	}

	@Override
	public void setInterfaceEntities(List<InterfaceEntity> entities) {
		removeChildren(interfaceEntities);
		interfaceEntities = entities;
		addChildren(interfaceEntities);
	}

	@Override
	public void setInterfaceFolders(List<InterfaceFolder> interfaceFolders) {
		removeChildren(this.interfaceFolders);
		this.interfaceFolders = interfaceFolders;
		addChildren(interfaceFolders);
	}

}
