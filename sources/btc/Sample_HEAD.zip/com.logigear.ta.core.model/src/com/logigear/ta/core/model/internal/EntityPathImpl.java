package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.EntityPath;

public abstract class EntityPathImpl extends EntityImpl implements EntityPath {

	private Path path;
	
	public EntityPathImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
	}

	@Override
	public Path getPath() {
		return path;
	}

	@Override
	public void setPath(Path path) {
		this.path = path;
	}
}
