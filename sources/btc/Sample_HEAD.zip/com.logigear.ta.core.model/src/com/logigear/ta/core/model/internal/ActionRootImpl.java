package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.ActionRoot;
import com.logigear.ta.core.model.Entity;

public class ActionRootImpl extends ActionFolderImpl implements ActionRoot {

	public ActionRootImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}
	
	public ActionRootImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}
}
