package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.AbtAction;
import com.logigear.ta.core.model.Argument;
import com.logigear.ta.core.model.Entity;

public class AbtActionImpl extends EntityVariatingImpl implements AbtAction {
	private String description;
	List<Argument> arguments = new ArrayList<>();

	public AbtActionImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}

	public AbtActionImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public List<Argument> getArguments() {
		return arguments;
	}

	@Override
	public void setArguments(List<Argument> arguments) {
		removeChildren(this.arguments);
		this.arguments = arguments;
		addChildren(arguments);
	}

}
