package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.DatasetRoot;
import com.logigear.ta.core.model.Entity;

public class DatasetRootImpl extends DatasetFolderImpl implements DatasetRoot {

	public DatasetRootImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}
	
	public DatasetRootImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}
}
