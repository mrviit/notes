package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.AbtAction;
import com.logigear.ta.core.model.ActionFolder;
import com.logigear.ta.core.model.Entity;

public class ActionFolderImpl extends EntityFolderImpl implements ActionFolder{
	
	private List<ActionFolder> actionFolders = new ArrayList<ActionFolder>();
	private List<AbtAction> actions = new ArrayList<AbtAction>();

	public ActionFolderImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}
	
	public ActionFolderImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}

	@Override
	public List<AbtAction> getActions(boolean isRecursive) {
		return actions;
	}

	@Override
	public List<ActionFolder> getActionFolders(boolean isRecursive) {
		return actionFolders;
	}

	@Override
	public void addAction(AbtAction action) {
		actions.add(action);
		addChild(action);		
	}

	@Override
	public void addActionFolder(ActionFolder actionFolder) {
		actionFolders.add(actionFolder);
		addChild(actionFolder);		
	}

	@Override
	public void setActions(List<AbtAction> actions) {
		removeChildren(this.actions);
		this.actions = actions; 
		addChildren(actions);
	}

	@Override
	public void setActionFolders(List<ActionFolder> datasetFolders) {
		removeChildren(this.actionFolders);
		this.actionFolders = datasetFolders; 
		addChildren(datasetFolders);
	}

}
