package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.Interface;
import com.logigear.ta.core.model.InterfaceRoot;

public class InterfaceRootImpl extends EntityImpl implements InterfaceRoot{

	private String defaultInterfaceName;
	private Path path;
	
	public InterfaceRootImpl(String name, Entity parent, Path path) {
		super(name, parent, null);
		this.path = path;
	}
	
	public InterfaceRootImpl(String name, Entity parent, List<Entity> children, Path path, String defaultInterfaceName) {
		super(name, parent, children);
		this.defaultInterfaceName = defaultInterfaceName;
		this.path = path;
	}

	@Override
	public Path getPath() {
		return path;
	}

	@Override
	public void setPath(Path path) {
		this.path = path;
	}

	@Override
	public List<Interface> getInterfaces() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addInterface(Interface interface1) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getDefaultInterfaceName() {
		return defaultInterfaceName;
	}
}
