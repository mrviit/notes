package com.logigear.ta.core.model;

import java.util.List;

public interface DatasetRoot extends Entity {
	
	List<Dataset> getDatasets(boolean isRecursive);

	List<DatasetFolder> getDatasetFolders(boolean isRecursive);

	void addDataset(Dataset dataset);

	void addDatasetFolder(DatasetFolder datasetFolder);
}
