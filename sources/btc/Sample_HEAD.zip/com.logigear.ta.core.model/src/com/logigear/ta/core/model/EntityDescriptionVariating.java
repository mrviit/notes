package com.logigear.ta.core.model;


public interface EntityDescriptionVariating extends Entity{
	
	String getDescription();
	void setDescription(String description);
}
