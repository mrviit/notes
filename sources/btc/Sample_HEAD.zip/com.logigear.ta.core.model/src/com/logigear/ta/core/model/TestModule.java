package com.logigear.ta.core.model;

import java.util.List;

public interface TestModule extends EntityVariating {
	
	List<TestObjective> getTestObjectives();
	void setTestObjectives(List<TestObjective> testObjectives);

	List<TestCase> getTestCases();
	void setTestCases(List<TestCase> testCases);
	
}
