package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.EntityVariatingDescription;

public abstract class EntityVariatingDescriptionImpl extends EntityDescriptionImpl implements EntityVariatingDescription {

	public EntityVariatingDescriptionImpl(String name, Entity parent, Path path) {
		super(name, parent, null);
	}
	
	public EntityVariatingDescriptionImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children);
	}
}
