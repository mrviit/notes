package com.logigear.ta.core.model.internal;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceElement;

public class InterfaceElementImpl extends EntityDescriptionImpl implements InterfaceElement {

	private String taClass;

	public InterfaceElementImpl(String name, Entity parent) {
		super(name, parent, null);
	}

	@Override
	public String getTAClass() {
		return taClass;
	}

	@Override
	public void setTAClass(String taClass) {
		this.taClass = taClass;

	}
}
