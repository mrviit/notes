package com.logigear.ta.core.model.internal;

import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.Project;
import com.logigear.ta.core.model.ProjectConfiguration;

public class ProjectImpl extends EntityImpl implements Project{	

	private ProjectConfiguration projectConfiguration;
	
	public ProjectImpl(String name) {
		super(name, null, null);
	}

	@Override
	public ProjectConfiguration getConfigurations() {
		return projectConfiguration;
	}

	@Override
	public void setProjectConfiguration(ProjectConfiguration projectConfiguration) {
		this.projectConfiguration = projectConfiguration;		
	}
	
	public List<Entity> getChildren() {
		List<Entity> children = super.getChildren();
		
		if(children == null || children.size() < 1) {
			super.addChild(projectConfiguration.getTestRoot());
			super.addChild(projectConfiguration.getDataRoot());
			super.addChild(projectConfiguration.getActionRoot());
			super.addChild(projectConfiguration.getInterfaceRoot());
			children = super.getChildren();
		}
		
		return children;
	}

	@Override
	public String toString() {
		return getName();
	}

}
