package com.logigear.ta.core.model;

public interface InterfaceEntitySetting extends Entity {
	
	String getName();
	
	void setName(String name);
	
	String getValue();
	
	void setValue(String value);

}
