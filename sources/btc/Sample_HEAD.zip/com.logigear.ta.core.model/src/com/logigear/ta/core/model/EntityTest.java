package com.logigear.ta.core.model;

public interface EntityTest extends Entity {
	String getId();
	void setId(String id);
	
	String getTitle();
	void setTitle(String title);
}
