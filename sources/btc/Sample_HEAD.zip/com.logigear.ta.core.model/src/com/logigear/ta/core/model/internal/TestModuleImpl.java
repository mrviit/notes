package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestCase;
import com.logigear.ta.core.model.TestModule;
import com.logigear.ta.core.model.TestObjective;


public class TestModuleImpl extends EntityVariatingImpl implements TestModule {

	private List<TestCase> testCases = new ArrayList<>();
	private List<TestObjective> testObjectives = new ArrayList<>();
	
	public TestModuleImpl(String name, Entity parent, Path path) {
		super(name, parent, null);	
		setPath(path);
	}

	@Override
	public List<TestObjective> getTestObjectives() {
		return testObjectives;
	}

	@Override
	public List<TestCase> getTestCases() {
		return testCases;
	}

	@Override
	public void setTestObjectives(List<TestObjective> testObjectives) {
		removeChildren(this.testObjectives);
		this.testObjectives = testObjectives;
		addChildren(testObjectives);
	}

	@Override
	public void setTestCases(List<TestCase> testCases) {
		removeChildren(this.testCases);
		this.testCases = testCases;
		addChildren(testCases);
	}
}
