package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Dataset;
import com.logigear.ta.core.model.DatasetFolder;
import com.logigear.ta.core.model.Entity;

public class DatasetFolderImpl extends EntityFolderImpl implements DatasetFolder{
	
	private List<DatasetFolder> datasetFolders = new ArrayList<DatasetFolder>();
	private List<Dataset> datasets = new ArrayList<Dataset>();

	public DatasetFolderImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}
	
	public DatasetFolderImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}

	@Override
	public List<Dataset> getDatasets(boolean isRecursive) {
		return datasets;
	}

	@Override
	public List<DatasetFolder> getDatasetFolders(boolean isRecursive) {
		return datasetFolders;
	}

	@Override
	public void addDataset(Dataset dataset) {
		datasets.add(dataset);
		addChild(dataset);		
	}

	@Override
	public void addDatasetFolder(DatasetFolder datasetFolder) {
		datasetFolders.add(datasetFolder);
		addChild(datasetFolder);		
	}

	@Override
	public void setDatasets(List<Dataset> datasets) {
		removeChildren(this.datasets);
		this.datasets = datasets; 
		addChildren(datasets);
	}

	@Override
	public void setDatasetFolders(List<DatasetFolder> datasetFolders) {
		removeChildren(this.datasetFolders);
		this.datasetFolders = datasetFolders; 
		addChildren(datasetFolders);
	}
}
