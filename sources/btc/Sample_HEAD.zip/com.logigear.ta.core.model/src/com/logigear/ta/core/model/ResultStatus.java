package com.logigear.ta.core.model;

public enum ResultStatus {

	PASSED,
	FAILED
}
