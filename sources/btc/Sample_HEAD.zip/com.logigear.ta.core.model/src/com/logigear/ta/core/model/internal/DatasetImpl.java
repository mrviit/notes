package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Dataset;
import com.logigear.ta.core.model.Entity;

public class DatasetImpl extends EntityVariatingImpl implements Dataset {
	
	public DatasetImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}

	public DatasetImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}

	@Override
	public List<String> getColumnNames() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

}
