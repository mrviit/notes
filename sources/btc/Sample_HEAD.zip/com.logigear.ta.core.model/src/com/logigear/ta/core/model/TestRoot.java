package com.logigear.ta.core.model;

public interface TestRoot extends TestFolder {
	

}
