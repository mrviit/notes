package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestFolder;
import com.logigear.ta.core.model.TestModule;

public class TestFolderImpl extends EntityFolderImpl implements TestFolder {

	private List<TestFolder> testFolders = new ArrayList<TestFolder>();
	private List<TestModule> testModules = new ArrayList<TestModule>();
	
	
	public TestFolderImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}
	
	public TestFolderImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}

	@Override
	public void addTestFolders(List<TestFolder> testFolders) {
		if(testFolders == null) return;
		
		this.testFolders.addAll(testFolders);	
		addChildren(testFolders);
	}

	@Override
	public void addTestFolder(TestFolder testFolder) {
		testFolders.add(testFolder);
		addChild(testFolder);
	}

	@Override
	public void addTestModules(List<TestModule> testModules) {
		this.testModules.addAll(testModules);
		addChildren(testModules);
	}

	@Override
	public void addTestModule(TestModule testModule) {
		testModules.add(testModule);	
		addChild(testModule);
	}

	@Override
	public List<TestFolder> getTestFolders(boolean isRecursive) {
		return testFolders;
	}

	@Override
	public List<TestModule> getTestModules(boolean isRecursive) {
		return testModules;
	}

	@Override
	public void setTestFolders(List<TestFolder> testFolders) {
		removeChildren(this.testFolders);
		this.testFolders = testFolders;
		addChildren(testFolders);
	}

	@Override
	public void setTestModules(List<TestModule> testModules) {
		removeChildren(this.testModules);
		this.testModules = testModules;
		addChildren(testModules);
	}
}
