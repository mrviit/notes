package com.logigear.ta.core.model;


public interface EntityDescription extends Entity{
	
	String getDescription();
	void setDescription(String description);
}
