package com.logigear.ta.core.model;

public interface TestObjective extends EntityTestDescription{
	
	int getTestCoverages();
	void setTestCoverages(int value);

}
