package com.logigear.ta.core.model;

public interface InterfaceElement extends Entity {
	
	String getTAClass();
	
	void setTAClass(String taClass);
	
	String getDescription();
	
	void setDescription(String description);
	

}
