package com.logigear.ta.core.model.internal;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.EntityFile;

public abstract class EntityFileImpl extends EntityPathImpl implements EntityFile {

	public EntityFileImpl(String name, Entity parent, Path path) {
		super(name, parent, null);
		setPath(path);
	}

	public EntityFileImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children);
		setPath(path);
	}

	@Override
	public String getScript() throws IOException {
		return new String(Files.readAllBytes(getPath()));
	}

}
