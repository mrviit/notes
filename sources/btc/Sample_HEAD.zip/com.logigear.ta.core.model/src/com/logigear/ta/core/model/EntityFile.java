package com.logigear.ta.core.model;

import java.io.IOException;

public interface EntityFile extends EntityPath {
	
	String getScript() throws IOException;
}
