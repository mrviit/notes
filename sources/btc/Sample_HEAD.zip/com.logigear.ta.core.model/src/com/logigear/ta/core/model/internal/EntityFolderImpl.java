package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.EntityFolder;

public abstract class EntityFolderImpl extends EntityPathImpl implements EntityFolder {
	
	public EntityFolderImpl(String name, Entity parent, Path path) {
		this(name, parent, null, path);
//		super(name, parent, null);
//		setPath(path);
	}
	
	public EntityFolderImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children);
		setPath(path);
	}
}
