package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.EntityVariating;

public abstract class EntityVariatingImpl extends EntityFileImpl implements EntityVariating {

	private String configuration, systemversion;
	
	public EntityVariatingImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}

	public EntityVariatingImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}

	@Override
	public String getConfiguration() {
		return configuration;
	}

	@Override
	public void setConfiguration(String configuration) {
		this.configuration = configuration;

	}

	@Override
	public String getSystemVersion() {
		return systemversion;
	}

	@Override
	public void setSystemVersion(String systemversion) {
		this.systemversion = systemversion;
	}

	@Override
	public String getBaseName() {
		return getName();
	}

}
