package com.logigear.ta.core.model;

import java.util.List;

public interface AbtAction extends EntityVariating {

	String getDescription();

	void setDescription(String description);

	List<Argument> getArguments();

	void setArguments(List<Argument> arguments);

}
