package com.logigear.ta.core.model;

import java.util.List;

public interface ActionRoot extends Entity {
	
	List<AbtAction> getActions(boolean isRecursive);

	List<ActionFolder> getActionFolders(boolean isRecursive);

	void addAction(AbtAction action);

	void addActionFolder(ActionFolder actionFolder);
}
