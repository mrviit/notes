package com.logigear.ta.core.model;


public interface EntityVariatingDescription extends EntityPath{
	
	String getDescription();
	void setDescription(String description);
}
