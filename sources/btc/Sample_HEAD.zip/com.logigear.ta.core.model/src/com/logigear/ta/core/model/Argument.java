package com.logigear.ta.core.model;

public interface Argument extends Entity{
	
	String getDescription();
	
	void setDescription(String description);
	
	String getType();
	
	void setType(String type);
	
	String getModifier();
	
	void setModifier(String modifier);
	
	String getDefaultValue();
	
	void setDefaultValue(String defaultValue);

}
