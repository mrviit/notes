package com.logigear.ta.core.model;

import java.util.List;

public interface Entity {
	
	String getName();	
	void setName(String name);
	
	Entity getParent();	
	void setParent(Entity parent);
	
	List<Entity> getChildren();
	
	void addChild(Entity entity);
	void addChildren(List<? extends Entity> entities);
	
	void removeChild(Entity entity);
	void removeChildren(List<? extends Entity> entities);
}
