package com.logigear.ta.core.model.internal;

import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Entity;

public abstract class EntityImpl implements Entity {
	
	private String name;
	private Entity parent;
	private List<Entity> children;
	
	
	public EntityImpl(String name, Entity parent, List<Entity> children) {
		this.name = name;
		this.parent = parent;
		this.children = children;
	}
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public Entity getParent() {
		return parent;
	}

	@Override
	public void setParent(Entity parent) {
		this.parent = parent;
	}

	@Override
	public List<Entity> getChildren() {
		return children;
	}

	@Override
	public void addChild(Entity entity) {
		if(entity == null) return;
		
		if(children == null) {
			children = new ArrayList<>();
		}
		children.add(entity);	
	}
	
	@Override
	public void addChildren(List<? extends Entity> entities) {
		if(entities == null) return;
		
		if(children == null) {
			children = new ArrayList<>();
		}
		children.addAll(entities);	
	}

	@Override
	public String toString() {
		return getName();
	}
	
	@Override
	public void removeChild(Entity entity) {
		if(entity == null) return;
		
		if(children != null) {
			children.remove(entity);
		}		
	}
	
	@Override
	public void removeChildren(List<? extends Entity> entities) {
		if(entities == null) return;
		
		if(children != null) {
			children.removeAll(entities);
		}
	}
}
