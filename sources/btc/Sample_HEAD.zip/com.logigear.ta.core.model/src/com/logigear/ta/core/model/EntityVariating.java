package com.logigear.ta.core.model;

public interface EntityVariating extends EntityFile{

	String getConfiguration();
	
	void setConfiguration(String configuration);
	
	String getSystemVersion();
	
	void setSystemVersion(String systemversion);
	
	String getBaseName();
}
