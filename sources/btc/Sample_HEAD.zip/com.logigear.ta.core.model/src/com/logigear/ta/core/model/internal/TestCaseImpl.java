package com.logigear.ta.core.model.internal;

import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestCase;
import com.logigear.ta.core.model.TestObjective;
import com.logigear.ta.core.model.TestStep;

public class TestCaseImpl extends /*EntityTestDescriptionImpl*/EntityTestImpl implements TestCase {

	private List<TestObjective> testObjectives = new ArrayList<>();	
	private List<TestStep> testSteps = new ArrayList<>();

	public TestCaseImpl(String name, Entity parent, List<Entity> children) {
		super(name, parent, children);
	}
	
	@Override
	public List<TestObjective> getTestObjectives() {
		return testObjectives;
	}
	
	@Override
	public void addTestObjective(TestObjective testObjective) {
		testObjectives.add(testObjective);		
	}

	@Override
	public List<TestStep> getTestSteps() {
		return testSteps;
	}

	@Override
	public void addTestStep(TestStep testStep) {
		testSteps.add(testStep);
		addChild(testStep);
	}
}
