package com.logigear.ta.core.model;


public interface EntityFolder extends EntityPath {

}
