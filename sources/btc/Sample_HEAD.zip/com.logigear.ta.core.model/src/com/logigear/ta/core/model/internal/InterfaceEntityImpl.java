package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceElement;
import com.logigear.ta.core.model.InterfaceEntity;
import com.logigear.ta.core.model.InterfaceEntitySetting;

public class InterfaceEntityImpl extends EntityVariatingImpl implements InterfaceEntity {

	private List<InterfaceEntitySetting> settings = new ArrayList<>();
	private List<InterfaceElement> elements = new ArrayList<>();
	
	public InterfaceEntityImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}
	
	public InterfaceEntityImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}

	@Override
	public List<InterfaceEntitySetting> getInterfaceEntitySetting() {
		return settings;
	}

	@Override
	public void setInterfaceEntitySetting(List<InterfaceEntitySetting> settings) {
		removeChildren(this.settings);
		this.settings = settings;
		addChildren(settings);
	}

	@Override
	public void addInterfaceEntitySetting(InterfaceEntitySetting setting) {
		settings.add(setting);
	}

	@Override
	public void removeInterfaceEntitySetting(InterfaceEntitySetting setting) {
		settings.remove(setting);
	}

	@Override
	public void setInterfaceElement(List<InterfaceElement> elements) {
		removeChildren(this.elements);
		this.elements = elements;
		addChildren(elements);
	}

}
