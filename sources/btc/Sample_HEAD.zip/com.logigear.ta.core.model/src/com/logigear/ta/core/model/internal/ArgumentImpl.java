package com.logigear.ta.core.model.internal;

import com.logigear.ta.core.model.Argument;
import com.logigear.ta.core.model.Entity;	

public class ArgumentImpl extends EntityImpl implements Argument {

	private String defaultValue;
	private String type;
	private String description;
	private String modifier;

	public ArgumentImpl(String name, Entity parent) {
		super(name, parent, null);
	}

	@Override
	public String getDescription() {
		return description;
	}

	@Override
	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String getType() {
		return type;
	}

	@Override
	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String getModifier() {
		return modifier;
	}

	@Override
	public void setModifier(String modifier) {
		this.modifier = modifier;
	}

	@Override
	public String getDefaultValue() {
		return defaultValue;
	}

	@Override
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

}
