package com.logigear.ta.core.model;

public interface Project extends Entity {
	
	String getName();
	
	void setName(String name);
	
	ProjectConfiguration getConfigurations();
	
	void setProjectConfiguration(ProjectConfiguration projectConfiguration);
}
