package com.logigear.ta.core.model;

import java.util.List;

public interface InterfaceEntity extends EntityVariating {
	
	List<InterfaceEntitySetting> getInterfaceEntitySetting();	
	void setInterfaceEntitySetting(List<InterfaceEntitySetting> settings);
	
	void addInterfaceEntitySetting(InterfaceEntitySetting setting);	
	void removeInterfaceEntitySetting(InterfaceEntitySetting setting);

	void setInterfaceElement(List<InterfaceElement> elements);
}
