package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestRoot;

public class TestRootImpl extends TestFolderImpl implements TestRoot {

	public TestRootImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}
	
	public TestRootImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}
}
