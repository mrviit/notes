package com.logigear.ta.core.model;

import java.util.List;

public interface TestCase extends EntityTestDescription {
	
	List<TestObjective> getTestObjectives();	
	void addTestObjective(TestObjective testObjective);
	
	List<TestStep> getTestSteps();	
	void addTestStep(TestStep testStep);	
}
