package com.logigear.ta.core.model.internal;

import java.nio.file.Path;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.Interface;

public class InterfaceImpl extends InterfaceFolderImpl implements Interface {

	private byte isDefault = 0;

	public InterfaceImpl(String name, Entity parent, Path path) {
		super(name, parent, path);
	}

	public InterfaceImpl(String name, Entity parent, List<Entity> children, Path path) {
		super(name, parent, children, path);
	}

	@Override
	public boolean isDefault() {
		return isDefault == 0 ? false : true;
	}

	@Override
	public void setDefaultInterface(boolean isDefault) {
		if (isDefault) {
			this.isDefault = 1;
		} else {
			this.isDefault = 0;
		}

	}

}
