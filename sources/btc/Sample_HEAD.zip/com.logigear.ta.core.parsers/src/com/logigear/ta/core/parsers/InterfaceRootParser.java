package com.logigear.ta.core.parsers;

import java.nio.file.Path;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceRoot;

public interface InterfaceRootParser {
	
	public InterfaceRoot parse(String name, Entity parent, Path path);
}
