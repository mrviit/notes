package com.logigear.ta.core.parsers.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.AbtAction;
import com.logigear.ta.core.model.Argument;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.internal.AbtActionImpl;
import com.logigear.ta.core.model.internal.ArgumentImpl;
import com.logigear.ta.core.parsers.ActionParser;


public class ActionParserImpl implements ActionParser {

	@Override
	public AbtAction parse(String name, Entity parent, Path path) {
		AbtAction action = new AbtActionImpl(name, parent, path);
		action.setArguments(acquireArguments(action, path));
		return action;
	}
	
	private List<Argument> acquireArguments(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		List<Argument> arguments = new ArrayList<Argument>();
		try {
			BufferedReader br = Files.newBufferedReader(path);
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith("argument")) {
					String[] cells = line.split("\t");
					Argument argument = new ArgumentImpl(cells[1], parent);
					arguments.add(argument);
				}
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return arguments;
	}
}
