package com.logigear.ta.core.parsers.internal;

import java.nio.file.Path;
import com.logigear.ta.core.model.DatasetFolder;
import com.logigear.ta.core.model.DatasetRoot;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.internal.DatasetRootImpl;
import com.logigear.ta.core.parsers.DatasetFolderParser;
import com.logigear.ta.core.parsers.DatasetRootParser;


public class DatasetRootParserImpl implements DatasetRootParser {

	@Override
	public DatasetRoot parse(String name, Entity parent, Path path) {
		DatasetFolderParser datasetFolderParser = new DatasetFolderParserImpl();
		DatasetFolder datasetFolder = datasetFolderParser.parse(name, parent, path);
		if(datasetFolder != null) {
			DatasetRoot datasetRoot = new DatasetRootImpl(
					datasetFolder.getName(), 
					datasetFolder.getParent(), 
					datasetFolder.getChildren(), 
					datasetFolder.getPath());	
			return datasetRoot;
		}
		return null;
	}
}
