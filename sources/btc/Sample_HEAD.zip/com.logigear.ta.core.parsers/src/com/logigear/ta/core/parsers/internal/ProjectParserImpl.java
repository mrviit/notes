package com.logigear.ta.core.parsers.internal;

import java.nio.file.Path;
import com.logigear.ta.core.model.Project;
import com.logigear.ta.core.model.ProjectConfiguration;
import com.logigear.ta.core.model.internal.ProjectImpl;
import com.logigear.ta.core.parsers.ProjectConfigurationParser;
import com.logigear.ta.core.parsers.ProjectParser;
import com.logigear.ta.core.parsers.util.JsonParser;


public class ProjectParserImpl implements ProjectParser {
		
	@Override
	public Project parse(Path projectFolderPath, String projectFileName, String projectConfigFileName) {
		Project project = acquireProject(projectFolderPath, projectFileName);
		if(project == null) {
			System.out.println("Cannot acquire the project");
			return null;
		}
		
		ProjectConfiguration config = acquireConfig(project, projectFolderPath, projectConfigFileName);
		if(config == null) {
			System.out.println("Cannot acquire the project configuration");
			return null;
		}		
		project.setProjectConfiguration(config);
				
		return project;
	}
	
	private Project acquireProject(String projectNameJPath, Path projectFolderPath, String projectFileName) {
		Path projectJsonFilePath = projectFolderPath.resolve(projectFileName);
		Object projectNameNode = JsonParser.instance(projectJsonFilePath).fetchNode(projectNameJPath);
		if(projectNameNode == null) {
			System.out.println("No project name existing");
			return null;
		}
		return new ProjectImpl(projectNameNode.toString());
	}
	
	private Project acquireProject(Path projectFolderPath, String projectFileName) {
		return acquireProject("$.project.name", projectFolderPath, projectFileName);		
	}
	
	private ProjectConfiguration acquireConfig(Project project, Path projectFolderPath, String projectConfigFileName) {				
		ProjectConfigurationParser configParser = new ProjectConfigurationParserImpl();
		Path projectConfigJsonFilePath = projectFolderPath.resolve(projectConfigFileName);
		return configParser.parse(project, projectConfigJsonFilePath);
	}
}
