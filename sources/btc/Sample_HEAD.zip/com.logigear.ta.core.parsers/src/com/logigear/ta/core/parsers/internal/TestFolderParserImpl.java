package com.logigear.ta.core.parsers.internal;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestFolder;
import com.logigear.ta.core.model.TestModule;
import com.logigear.ta.core.model.internal.TestFolderImpl;
import com.logigear.ta.core.parsers.TestFolderParser;
import com.logigear.ta.core.parsers.TestModuleParser;


public class TestFolderParserImpl implements TestFolderParser {

	@Override
	public TestFolder parse(String name, Entity parent, Path path) {
		TestFolder testFolder = new TestFolderImpl(name, parent, path);
		List<TestModule> testModules = acquireTestModules(testFolder, path); 
		List<TestFolder> testFolders = acquireTestFolders(testFolder, path);
		testFolder.setTestModules(testModules);
		testFolder.setTestFolders(testFolders);
		return testFolder;
	}

	
	private List<TestFolder> acquireTestFolders(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] subdirs = path.toFile().listFiles(File::isDirectory);
		List<TestFolder> testFolders = new ArrayList<TestFolder>();
		for(File dir : subdirs) {
			TestFolder testFolder = new TestFolderImpl(dir.getName(), parent, dir.toPath());
			List<TestModule> testModules = acquireTestModules(testFolder, dir.toPath()); 
			testFolder.setTestModules(testModules);
			List<TestFolder> subTestFolders = acquireTestFolders(testFolder, dir.toPath());
			testFolder.setTestFolders(subTestFolders);
			testFolders.add(testFolder);
		}
		return testFolders;
	}
	
	private List<TestModule> acquireTestModules(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] modules = path.toFile().listFiles(File::isFile);
		List<TestModule> testModules = new ArrayList<TestModule>();
		TestModuleParser testModuleParser = new TestModuleParserImpl();
		for(File module : modules) {
			TestModule testModule = testModuleParser.parse(module.getName().split("\\.")[0], parent, module.toPath());
			if(testModule != null) {
				testModules.add(testModule);		
			}
		}
		return testModules;
	}
}
