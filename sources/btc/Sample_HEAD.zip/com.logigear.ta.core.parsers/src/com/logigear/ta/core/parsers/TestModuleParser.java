package com.logigear.ta.core.parsers;

import java.nio.file.Path;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestModule;

public interface TestModuleParser {
	
	public TestModule parse(String name, Entity parent, Path path);
	
}
