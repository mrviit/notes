package com.logigear.ta.core.parsers;

import java.nio.file.Path;

import com.logigear.ta.core.model.ActionFolder;
import com.logigear.ta.core.model.Entity;

public interface ActionFolderParser {
	
	public ActionFolder parse(String name, Entity parent, Path path);
}
