package com.logigear.ta.core.parsers;

import java.nio.file.Path;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestFolder;

public interface TestFolderParser {
	
	public TestFolder parse(String name, Entity parent, Path path);
	
}
