package com.logigear.ta.core.parsers.internal;

import java.nio.file.Path;

import com.logigear.ta.core.model.ActionFolder;
import com.logigear.ta.core.model.ActionRoot;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.internal.ActionRootImpl;
import com.logigear.ta.core.parsers.ActionFolderParser;
import com.logigear.ta.core.parsers.ActionRootParser;


public class ActionRootParserImpl implements ActionRootParser {

	@Override
	public ActionRoot parse(String name, Entity parent, Path path) {
		ActionFolderParser actionFolderParser = new ActionFolderParserImpl();
		ActionFolder actionFolder = actionFolderParser.parse(name, parent, path);
		if(actionFolder != null) {
			return new ActionRootImpl(
					actionFolder.getName(), 
					actionFolder.getParent(), 
					actionFolder.getChildren(), 
					actionFolder.getPath());	
		}
		return null;
	}

}
