package com.logigear.ta.core.parsers.internal;

import java.nio.file.Path;
import java.util.List;
import java.util.function.Predicate;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceFolder;
import com.logigear.ta.core.model.InterfaceRoot;
import com.logigear.ta.core.model.internal.InterfaceRootImpl;
import com.logigear.ta.core.parsers.InterfaceFolderParser;
import com.logigear.ta.core.parsers.InterfaceRootParser;
import com.logigear.ta.core.parsers.util.JsonParser;


public class InterfaceRootParserImpl implements InterfaceRootParser {

	private static final String JPATH_DEFAULT_INTERFACE = "$.default_interface";
	private static final String DEFAULT_INTERFACE_CONFIG = "default_interface.config";
	
	@Override
	public InterfaceRoot parse(String name, Entity parent, Path path) {
		InterfaceFolderParser interfaceFolderParser = new InterfaceFolderParserImpl();
		InterfaceFolder interfaceFolder = interfaceFolderParser.parse(name, parent, path);
		if(interfaceFolder != null) {
			List<Entity> children = interfaceFolder.getChildren();
			children.removeIf(new Predicate<Entity>() {
				@Override
				public boolean test(Entity arg0) {
					return arg0.getName().equals("default_interface");
				}
			});

			Path defaultInterfaceConfig = path.resolve(DEFAULT_INTERFACE_CONFIG); 
			Object pathValue = JsonParser.instance(defaultInterfaceConfig).fetchNode(JPATH_DEFAULT_INTERFACE);
			String defaultInterface = pathValue.toString();
			InterfaceRoot interfaceRoot = new InterfaceRootImpl(
					interfaceFolder.getName(), 
					interfaceFolder.getParent(), 
					children, 
					interfaceFolder.getPath(),
					defaultInterface);	
			return interfaceRoot;
		}
		return null;
	}

}
