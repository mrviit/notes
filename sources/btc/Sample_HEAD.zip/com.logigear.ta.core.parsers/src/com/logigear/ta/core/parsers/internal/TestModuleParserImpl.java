package com.logigear.ta.core.parsers.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestCase;
import com.logigear.ta.core.model.TestModule;
import com.logigear.ta.core.model.TestObjective;
import com.logigear.ta.core.model.TestStep;
import com.logigear.ta.core.model.internal.TestCaseImpl;
import com.logigear.ta.core.model.internal.TestModuleImpl;
import com.logigear.ta.core.model.internal.TestObjectiveImpl;
import com.logigear.ta.core.model.internal.TestStepImpl;
import com.logigear.ta.core.parsers.TestModuleParser;


public class TestModuleParserImpl implements TestModuleParser {

	private static final String FINAL = "FINAL";
	private static final String STEP = "step";
	private static final String TEST_CASE = "TEST CASE";
	private static final String TAB = "\t";
	private static final String TEST_OBJECTIVE = "test objective";
	private static final String OBJECTIVES = "OBJECTIVES";
	private static final String EMPTY_STRING = "";
	
	@Override
	public TestModule parse(String name, Entity parent, Path path) {
		TestModule testModule = new TestModuleImpl(name, parent, path);
		List<TestObjective> testModules = acquireTestObjectives(testModule, path); 
		List<TestCase> testFolders = acquireTestCases(testModule, path);
		testModule.setTestObjectives(testModules);
		testModule.setTestCases(testFolders);
		return testModule;
	}

	private List<TestObjective> acquireTestObjectives(Entity parent, Path path) {
		if(Files.notExists(path)) return null;

		List<TestObjective> testCases = new ArrayList<TestObjective>();
		try {
			BufferedReader br = Files.newBufferedReader(path);
			String line;
			while ((line = br.readLine()) != null) {
                if (line.startsWith(OBJECTIVES)) {
                	while ((line = br.readLine()) != null) {
                		if(line.startsWith(TEST_OBJECTIVE)) {
                			String[] cells = line.split(TAB);
                			TestObjective testCase = new TestObjectiveImpl(cells[1], parent, null);
                			testCase.setTitle(cells[2]);
                			testCases.add(testCase);
                		} else if(line.trim().equals(EMPTY_STRING)) {
                			continue;
                		} else break;
                	}
                    break;
                }
            }
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return testCases;
	}
	
	private List<TestCase> acquireTestCases(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		List<String> lines = new ArrayList<>();
		try {
			BufferedReader br = Files.newBufferedReader(path); 
			String line;
			while ((line = br.readLine()) != null) {
				if (line.startsWith(TEST_CASE) || line.startsWith(STEP)) {
					lines.add(line);
                } else if(line.startsWith(FINAL)) {
                	break;
                }
            }
			br.close();			
		} catch (IOException e) {
			e.printStackTrace();
		}

		List<TestCase> testCases = new ArrayList<TestCase>();
		TestCase testCase = null;
		for(String line : lines) {
			if (line.startsWith(TEST_CASE)) {
				String[] cells = line.split(TAB);
				testCase = new TestCaseImpl(cells[1], parent, null);
				testCase.setTitle(cells[2]);				
				testCases.add(testCase);
			} else if (line.startsWith(STEP) && testCase != null) {
				String[] cells = line.split(TAB);
				String id = cells[1].split("[a-z\\.]")[0];
				TestStep testStep = new TestStepImpl(id , testCase, null);
				testStep.setTitle(cells[1].replaceFirst(id + "\\.", "Step " + id + ","));
				testCase.addTestStep(testStep);
			} else testCase = null;
		}
		return testCases;
	}
}
