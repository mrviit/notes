package com.logigear.ta.core.parsers.internal;

import java.nio.file.Path;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.TestFolder;
import com.logigear.ta.core.model.TestRoot;
import com.logigear.ta.core.model.internal.TestRootImpl;
import com.logigear.ta.core.parsers.TestFolderParser;
import com.logigear.ta.core.parsers.TestRootParser;


public class TestRootParserImpl implements TestRootParser {

	@Override
	public TestRoot parse(String name, Entity parent, Path path) {
		TestFolderParser testFolderParser = new TestFolderParserImpl();
		TestFolder testFolder = testFolderParser.parse(name, parent, path);
		if(testFolder != null) {
			return new TestRootImpl(
					testFolder.getName(), 
					testFolder.getParent(), 
					testFolder.getChildren(), 
					testFolder.getPath());	//Entity
		}
		return null;
	}
}
