package com.logigear.ta.core.parsers.internal;

import java.nio.file.Path;
import com.jayway.jsonpath.JsonPath;
import com.logigear.ta.core.model.ActionRoot;
import com.logigear.ta.core.model.DatasetRoot;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceRoot;
import com.logigear.ta.core.model.ProjectConfiguration;
import com.logigear.ta.core.model.TestRoot;
import com.logigear.ta.core.model.internal.ProjectConfigurationImpl;
import com.logigear.ta.core.parsers.ActionRootParser;
import com.logigear.ta.core.parsers.DatasetRootParser;
import com.logigear.ta.core.parsers.InterfaceRootParser;
import com.logigear.ta.core.parsers.ProjectConfigurationParser;
import com.logigear.ta.core.parsers.TestRootParser;
import com.logigear.ta.core.parsers.util.JsonParser;

public class ProjectConfigurationParserImpl implements ProjectConfigurationParser {

	@Override
	public ProjectConfiguration parse(Entity parent, Path projectConfigJsonFilePath) {
		TestRoot testRoot = acquireTestRoot(parent, projectConfigJsonFilePath);
		if(testRoot == null) {
			System.out.println("Cannot acquire the testRoot");
			return null;
		}
		
		DatasetRoot datasetRoot = acquireDatasetRoot(parent, projectConfigJsonFilePath);
		if(datasetRoot == null) {
			System.out.println("Cannot acquire the datasetRoot");
			return null;
		}
		
		ActionRoot actionRoot = acquireActionRoot(parent, projectConfigJsonFilePath);
		if(actionRoot == null) {
			System.out.println("Cannot acquire the actionRoot");
			return null;
		}
		
		InterfaceRoot interfaceRoot = acquireInterfaceRoot(parent, projectConfigJsonFilePath);
		if(interfaceRoot == null) {
			System.out.println("Cannot acquire the interfaceRoot");
			return null;
		}
		
		ProjectConfiguration projectConfig = new ProjectConfigurationImpl();
		projectConfig.setTestRoot(testRoot);
		projectConfig.setDatasetRoot(datasetRoot);
		projectConfig.setActionRoot(actionRoot);
		projectConfig.setInterfaceRoot(interfaceRoot);
		
		return projectConfig;
	}
	
	private TestRoot acquireTestRoot(Entity parent, Path projectConfigJsonFilePath) {
		final String typeValue = "test";
		String pathValue = getTypePath(typeValue, projectConfigJsonFilePath); // result format ["value"]
		if(pathValue == null) {
			System.out.println("No path existing for " + typeValue);
			return null;
		}
		String name = JsonPath.read(pathValue, "$.[0]") 	//result format ["value"] -> extract value only
				.toString();
		Path path = projectConfigJsonFilePath.getParent().resolve(name);		
		TestRootParser testRootParser = new TestRootParserImpl();
		return testRootParser.parse(name, parent, path);
	}
	
	private DatasetRoot acquireDatasetRoot(Entity parent, Path projectConfigJsonFilePath) {
		final String typeValue = "test-data";
		String pathValue = getTypePath(typeValue, projectConfigJsonFilePath); // result format ["value"]
		if(pathValue == null) {
			System.out.println("No path existing for " + typeValue);
			return null;
		}
		String name = JsonPath.read(pathValue, "$.[0]") 	//result format ["value"] -> extract value only
				.toString();
		Path path = projectConfigJsonFilePath.getParent().resolve(name);
		DatasetRootParser datasetRootParser = new DatasetRootParserImpl();
		return datasetRootParser.parse(name, parent, path);
	}
	
	private ActionRoot acquireActionRoot(Entity parent, Path projectConfigJsonFilePath) {
		final String typeValue = "action";
		String pathValue = getTypePath(typeValue, projectConfigJsonFilePath); // result format ["value"]
		if(pathValue == null) {
			System.out.println("No path existing for " + typeValue);
			return null;
		}
		String name = JsonPath.read(pathValue, "$.[0]") 	//result format ["value"] -> extract value only
				.toString();
		Path path = projectConfigJsonFilePath.getParent().resolve(name);
		ActionRootParser actionRootParser = new ActionRootParserImpl();
		return actionRootParser.parse(name, parent, path);
	}
	
	private InterfaceRoot acquireInterfaceRoot(Entity parent, Path projectConfigJsonFilePath) {
		final String typeValue = "interface";
		String pathValue = getTypePath(typeValue, projectConfigJsonFilePath); // result format ["value"]
		if(pathValue == null) {
			System.out.println("No path existing for " + typeValue);
			return null;
		}
		String name = JsonPath.read(pathValue, "$.[0]") 	//result format ["value"] -> extract value only
				.toString();
		Path path = projectConfigJsonFilePath.getParent().resolve(name);
		InterfaceRootParser actionRootParser = new InterfaceRootParserImpl();
		return actionRootParser.parse(name, parent, path);
	}
	
	private String getTypePath(String typeValue, Path projectConfigJsonFilePath) {
		String nodeJPath = "$.classpath.classpathentry[?(@.type == '" + typeValue + "')]path";
		JsonParser jsParser = new JsonParser();
		jsParser.setJSonFilePath(projectConfigJsonFilePath);
		Object pathValue = jsParser.fetchNode(nodeJPath);		
		return pathValue.toString();
	}
}
