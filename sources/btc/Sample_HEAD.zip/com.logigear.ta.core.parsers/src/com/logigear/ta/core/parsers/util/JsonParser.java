package com.logigear.ta.core.parsers.util;

import com.jayway.jsonpath.DocumentContext;
import com.jayway.jsonpath.InvalidPathException;
import com.jayway.jsonpath.JsonPath;

import java.io.IOException;
import java.nio.file.Path;

public class JsonParser {
	
	public final static JsonParser instance = new JsonParser();
	
	public static JsonParser instance(Path jsonFilePath) {
		instance.setJSonFilePath(jsonFilePath);
		return instance;
	}
	
	private Path jsonFilePath;
	private DocumentContext docContext;
	
	public JsonParser() {}
	
	public JsonParser(Path jsonFilePath) {
		this.jsonFilePath = jsonFilePath;
	}
	
	public void setJSonFilePath(Path jsonFilePath) {
		this.jsonFilePath = jsonFilePath;
	}

	public Object fetchNode(String jsonPtrExpr) {						
		try {
			docContext = JsonPath.parse(jsonFilePath.toFile());
			return docContext.read(jsonPtrExpr);
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (InvalidPathException e1) {
			System.out.println("jsonPtrExpr " + jsonPtrExpr);
//			e1.printStackTrace();
		}		
		return null;
	}

}
