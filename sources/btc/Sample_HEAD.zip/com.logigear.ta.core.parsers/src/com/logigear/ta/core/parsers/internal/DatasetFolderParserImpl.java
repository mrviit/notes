package com.logigear.ta.core.parsers.internal;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Dataset;
import com.logigear.ta.core.model.DatasetFolder;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.internal.DatasetFolderImpl;
import com.logigear.ta.core.model.internal.DatasetImpl;
import com.logigear.ta.core.parsers.DatasetFolderParser;


public class DatasetFolderParserImpl implements DatasetFolderParser {

	@Override
	public DatasetFolder parse(String name, Entity parent, Path path) {
		DatasetFolder datasetFolder = new DatasetFolderImpl(name, parent, path);
		List<Dataset> datasets = acquireDatasets(datasetFolder, path); 
		List<DatasetFolder> datasetFolders = acquireDatasetFolders(datasetFolder, path);
		datasetFolder.setDatasets(datasets);
		datasetFolder.setDatasetFolders(datasetFolders);
		return datasetFolder;
	}
	
	private List<DatasetFolder> acquireDatasetFolders(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] subdirs = path.toFile().listFiles(File::isDirectory);
		List<DatasetFolder> datasetFolders = new ArrayList<DatasetFolder>();
		for(File dir : subdirs) {
			DatasetFolder datasetFolder = new DatasetFolderImpl(dir.getName(), parent, dir.toPath());
			List<Dataset> dataset = acquireDatasets(datasetFolder, dir.toPath()); 
			datasetFolder.setDatasets(dataset);
			List<DatasetFolder> subDatasetFolders = acquireDatasetFolders(datasetFolder, dir.toPath());
			datasetFolder.setDatasetFolders(subDatasetFolders);
			datasetFolders.add(datasetFolder);
		}
		return datasetFolders;
	}
	
	private List<Dataset> acquireDatasets(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] modules = path.toFile().listFiles(File::isFile);
		List<Dataset> datasets = new ArrayList<Dataset>();
		for(File module : modules) {
			Dataset dataset = new DatasetImpl(module.getName(), parent, module.toPath());
			datasets.add(dataset);					
		}
		return datasets;
	}
}
