package com.logigear.ta.core.parsers;

import java.nio.file.Path;

import com.logigear.ta.core.model.Project;

public interface ProjectParser {

	public Project parse(Path projectDirPath, String projectFileName, String projectConfigFileName);
	
}
