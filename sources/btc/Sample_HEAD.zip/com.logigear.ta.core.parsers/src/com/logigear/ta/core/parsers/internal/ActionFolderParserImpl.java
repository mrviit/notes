package com.logigear.ta.core.parsers.internal;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.AbtAction;
import com.logigear.ta.core.model.ActionFolder;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.internal.ActionFolderImpl;
import com.logigear.ta.core.parsers.ActionFolderParser;
import com.logigear.ta.core.parsers.ActionParser;


public class ActionFolderParserImpl implements ActionFolderParser {

	@Override
	public ActionFolder parse(String name, Entity parent, Path path) {
		ActionFolder actionFolder = new ActionFolderImpl(name, parent, path);
		List<AbtAction> actions = acquireActions(actionFolder, path); 
		List<ActionFolder> actionFolders = acquireActionFolders(actionFolder, path);
		actionFolder.setActions(actions);
		actionFolder.setActionFolders(actionFolders);
		return actionFolder;
	}

	private List<ActionFolder> acquireActionFolders(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] subdirs = path.toFile().listFiles(File::isDirectory);
		List<ActionFolder> actionFolders = new ArrayList<ActionFolder>();
		for(File dir : subdirs) {
			ActionFolder actionFolder = new ActionFolderImpl(dir.getName(), parent, dir.toPath());
			List<AbtAction> actions = acquireActions(actionFolder, dir.toPath()); 
			actionFolder.setActions(actions);
			List<ActionFolder> subActionFolders = acquireActionFolders(actionFolder, dir.toPath());
			actionFolder.setActionFolders(subActionFolders);
			actionFolders.add(actionFolder);
		}
		return actionFolders;
	}
	
	private List<AbtAction> acquireActions(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] modules = path.toFile().listFiles(File::isFile);
		List<AbtAction> actions = new ArrayList<AbtAction>();
		ActionParser actionParser = new ActionParserImpl();
		for(File module : modules) {
			AbtAction action = actionParser.parse(module.getName().split("\\.")[0], parent, module.toPath());
			if(action != null) {
				actions.add(action);		
			}
		}
		return actions;
	}
}
