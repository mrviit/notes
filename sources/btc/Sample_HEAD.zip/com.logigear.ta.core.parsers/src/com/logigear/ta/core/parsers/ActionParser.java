package com.logigear.ta.core.parsers;

import java.nio.file.Path;

import com.logigear.ta.core.model.AbtAction;
import com.logigear.ta.core.model.Entity;

public interface ActionParser {
	
	public AbtAction parse(String name, Entity parent, Path path);
	
}
