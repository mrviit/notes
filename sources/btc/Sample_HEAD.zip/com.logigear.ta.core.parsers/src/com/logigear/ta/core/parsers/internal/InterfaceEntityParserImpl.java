package com.logigear.ta.core.parsers.internal;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceElement;
import com.logigear.ta.core.model.InterfaceEntity;
import com.logigear.ta.core.model.internal.InterfaceElementImpl;
import com.logigear.ta.core.model.internal.InterfaceEntityImpl;
import com.logigear.ta.core.parsers.InterfaceEntityParser;


public class InterfaceEntityParserImpl implements InterfaceEntityParser {

	private static final String TAB = "\t";
	private static final String INTERFACE_ELEMENT = "interface element";
	
	@Override
	public InterfaceEntity parse(String name, Entity parent, Path path) {
		InterfaceEntity interfaceEntity = new InterfaceEntityImpl(name, parent, path);
		interfaceEntity.setInterfaceElement(acquireInterfaceElements(parent, path));
		return interfaceEntity;
	}

	private List<InterfaceElement> acquireInterfaceElements(Entity parent, Path path) {
		if(Files.notExists(path)) return null;

		List<InterfaceElement> testCases = new ArrayList<>();
		try {
			BufferedReader br = Files.newBufferedReader(path);
			String line;
			while ((line = br.readLine()) != null) {
                if (line.startsWith(INTERFACE_ELEMENT)) {
                	String[] cells = line.split(TAB);
                	InterfaceElement testCase = new InterfaceElementImpl(cells[1], parent);
                	testCases.add(testCase);
                }
            }
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return testCases;
	}
}
