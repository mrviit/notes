package com.logigear.ta.core.parsers;

import java.nio.file.Path;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceFolder;

public interface InterfaceFolderParser {
	
	public InterfaceFolder parse(String name, Entity parent, Path path);
	
}
