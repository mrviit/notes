package com.logigear.ta.core.parsers.internal;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Entity;
import com.logigear.ta.core.model.InterfaceEntity;
import com.logigear.ta.core.model.InterfaceFolder;
import com.logigear.ta.core.model.internal.InterfaceFolderImpl;
import com.logigear.ta.core.parsers.InterfaceEntityParser;
import com.logigear.ta.core.parsers.InterfaceFolderParser;


public class InterfaceFolderParserImpl implements InterfaceFolderParser {

	@Override
	public InterfaceFolder parse(String name, Entity parent, Path path) {
		InterfaceFolder interfaceFolder = new InterfaceFolderImpl(name, parent, path);
		List<InterfaceEntity> entities = acquireInterfaceEntities(interfaceFolder, path); 
		List<InterfaceFolder> interfaceFolders = acquireInterfaceFolders(interfaceFolder, path);
		interfaceFolder.setInterfaceEntities(entities);
		interfaceFolder.setInterfaceFolders(interfaceFolders);
		return interfaceFolder;
	}

	private List<InterfaceFolder> acquireInterfaceFolders(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] subdirs = path.toFile().listFiles(File::isDirectory);
		List<InterfaceFolder> interfaceFolders = new ArrayList<InterfaceFolder>();
		for(File dir : subdirs) {
			InterfaceFolder interfaceFolder = new InterfaceFolderImpl(dir.getName(), parent, dir.toPath());
			List<InterfaceEntity> entities = acquireInterfaceEntities(interfaceFolder, dir.toPath()); 
			interfaceFolder.setInterfaceEntities(entities);
			List<InterfaceFolder> subInterfaceFolders = acquireInterfaceFolders(interfaceFolder, dir.toPath());
			interfaceFolder.setInterfaceFolders(subInterfaceFolders);
			interfaceFolders.add(interfaceFolder);
		}
		return interfaceFolders;
	}
	
	private List<InterfaceEntity> acquireInterfaceEntities(Entity parent, Path path) {
		if(Files.notExists(path)) return null;
		
		File[] modules = path.toFile().listFiles(File::isFile);
		List<InterfaceEntity> entities = new ArrayList<InterfaceEntity>();
		InterfaceEntityParser interfaceEntityParser = new InterfaceEntityParserImpl();
		for(File module : modules) {
			InterfaceEntity entity = interfaceEntityParser.parse(module.getName().split("\\.")[0], parent, module.toPath());
			if(entity != null) {
				entities.add(entity);					
			}				
		}
		return entities;
	}
}
