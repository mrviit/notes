package com.logigear.ta.core.parsers.internal;

//import static org.junit.Assert.*;

//import java.nio.file.Paths;

import org.junit.Test;

public class ProjectParserImplTest {

	@Test
	public void testParse() {
		System.out.println("testParse");
//		ProjectParserImpl pp = new ProjectParserImpl();
//		assertTrue(pp.parse(Paths.get("E:\\TestArchitectHE_E4RCP\\Design\\ProjectModel\\Car Rental"), "project.json", "project.config.json"));
//		System.out.println("getProject " + pp.getProject().getName());
//		System.out.println("getTestRoot " + pp.getProject().getConfigurations().getTestRoot().getName());
//		System.out.println("getActionRoot " + pp.getProject().getConfigurations().getActionRoot().getName());
//		System.out.println("getDataRoot " + pp.getProject().getConfigurations().getDataRoot().getName());
//		System.out.println("getDataRoot " + pp.getProject().getConfigurations().getInterfaceRoot().getName());
	}
}
