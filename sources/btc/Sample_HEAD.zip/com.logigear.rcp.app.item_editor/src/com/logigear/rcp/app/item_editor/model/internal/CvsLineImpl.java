package com.logigear.rcp.app.item_editor.model.internal;

import org.apache.commons.csv.CSVRecord;

import com.logigear.rcp.app.item_editor.model.CvsLine;
import com.logigear.ta.core.model.EntityPath;

public class CvsLineImpl implements CvsLine {
	
	EntityPath parent;
	CSVRecord record;
	
	public CvsLineImpl(EntityPath parent, CSVRecord line) {
		this.parent = parent;
		record = line; 
	}
	
	@Override
	public String get(int column) {
		if(column < record.size())
			return record.get(column);
		return null;
	}
	
	@Override
	public long getLineNumber() {
		return record.getRecordNumber();
	}
	
}
