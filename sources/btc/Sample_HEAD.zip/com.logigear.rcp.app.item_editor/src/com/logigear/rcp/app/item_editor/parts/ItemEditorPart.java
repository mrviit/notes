
package com.logigear.rcp.app.item_editor.parts;

import javax.annotation.PostConstruct;
import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.jface.viewers.ArrayContentProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Table;
import com.logigear.rcp.app.common.EventsTopic;
import com.logigear.rcp.app.item_editor.handlers.OpenItemEditorHandler;


public class ItemEditorPart {

	private TableViewer viewer;
	
	@PostConstruct
	public void postConstruct(Composite parent, IEventBroker eventBroker) {
		createViewer(parent);
		
		eventBroker.subscribe(EventsTopic.OPEN_PROJECT_ITEM, new OpenItemEditorHandler(viewer));
	}
	
	private void createViewer(Composite parent) {
        viewer = new TableViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.FULL_SELECTION | SWT.BORDER);
        
        final Table table = viewer.getTable();
        table.setHeaderVisible(true);
        table.setLinesVisible(true);

        viewer.setContentProvider(/*new ItemEditorContentProvider()*/ArrayContentProvider.getInstance());

        // define layout for the viewer
        GridData gridData = new GridData();
        gridData.verticalAlignment = GridData.FILL;
        gridData.horizontalSpan = 2;
        gridData.grabExcessHorizontalSpace = true;
        gridData.grabExcessVerticalSpace = true;
        gridData.horizontalAlignment = GridData.FILL;
        viewer.getControl().setLayoutData(gridData);
    }
}