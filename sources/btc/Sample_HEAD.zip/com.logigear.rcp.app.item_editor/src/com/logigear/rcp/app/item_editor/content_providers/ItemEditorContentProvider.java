package com.logigear.rcp.app.item_editor.content_providers;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.eclipse.jface.viewers.IStructuredContentProvider;

import com.logigear.rcp.app.item_editor.model.CvsLine;
import com.logigear.rcp.app.item_editor.model.internal.CvsLineImpl;
import com.logigear.ta.core.model.TestModule;

public class ItemEditorContentProvider implements IStructuredContentProvider {

	@Override
	public Object[] getElements(Object inputElement) {
		
		List<CvsLine> cvsLines = new ArrayList<>();

		if(inputElement instanceof TestModule) {
			TestModule testModule = (TestModule)inputElement;
			Reader in = null;
			try {
				in = Files.newBufferedReader(testModule.getPath());
			} catch (IOException e) {
				e.printStackTrace();
			}
			CSVParser records = null;
			try {
				records = CSVFormat.TDF.parse(in);
			} catch (IOException e) {
				e.printStackTrace();
			}

			if(records == null) return null;

			for (CSVRecord record : records) {
				cvsLines.add(new CvsLineImpl(testModule, record));
			}
		}
		return cvsLines.toArray();
	}

}
