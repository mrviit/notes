package com.logigear.rcp.app.item_editor.handlers;

import com.logigear.rcp.app.item_editor.model.CvsLine;
import com.logigear.rcp.app.item_editor.model.internal.CvsLineImpl;
import com.logigear.ta.core.model.TestModule;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.jface.viewers.StyledCellLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.TableViewerColumn;
import org.eclipse.jface.viewers.ViewerCell;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.TableColumn;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;

public class OpenItemEditorHandler implements EventHandler {
	
	private TableViewer viewer;
	
	public OpenItemEditorHandler(TableViewer viewer) {
		this.viewer = viewer;
	}

	@Override
	public void handleEvent(Event event) {
		System.out.println("Process event: " + event.getTopic());
		Object object = event.getProperty(IEventBroker.DATA);
		if(object == null) return; 

		System.out.println("Processing item: " + object.getClass());
		
		if(object instanceof TestModule) {
			TestModule testModule = (TestModule)object;
			Reader in = null;
			try {
				in = Files.newBufferedReader(testModule.getPath());
			} catch (IOException e) {
				e.printStackTrace();
			}

			CSVParser cvsParser = null;
			try {
				cvsParser = CSVFormat.TDF.parse(in);
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			if(cvsParser == null) return;
			
			List<CSVRecord> records = null;
			try {
				records = cvsParser.getRecords();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			if(records != null) {
				createColumns(records.get(0).size());
				
				List<CvsLine> cvsLines = new ArrayList<>();
				for (CSVRecord record : records) {
					cvsLines.add(new CvsLineImpl(testModule, record));
				}
				viewer.setInput(cvsLines);
			}
		}
	}
	
	private void createColumns(long numColumns) {

        TableViewerColumn col = createTableViewerColumn("", 50, 0);
        col.setLabelProvider(new StyledCellLabelProvider() {
			@Override
			public void update(ViewerCell cell) { 
//				cell.setText(String.valueOf(viewer.getTable().indexOf((TableItem)cell.getItem()) + 1)); 
				cell.setText(String.valueOf(((CvsLine)cell.getElement()).getLineNumber()));
//				StyleRange myStyledRange =
//                        new StyleRange(16, 2, null,
//                                Display.getCurrent().getSystemColor(SWT.COLOR_YELLOW));
//                StyleRange[] range = { myStyledRange };
//                cell.setStyleRanges(range);
                cell.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_GRAY));
//                super.update(cell);
			}
		});
        
        for(int column = 0; column < numColumns; ++column) {
        	createTableViewerColumn(String.valueOf(Character.toChars(column + 'A')), 100, column);
        }
    }
	
	private TableViewerColumn createTableViewerColumn(String title, int bound, final int colNumber) {
        final TableViewerColumn viewerColumn = new TableViewerColumn(viewer, SWT.NONE);
        final TableColumn column = viewerColumn.getColumn();
        
        column.setText(title);
        column.setWidth(bound);
        column.setResizable(true);
        column.setMoveable(true);
        
        viewerColumn.setLabelProvider(new StyledCellLabelProvider() {
        	
        	@Override
			public void update(ViewerCell cell) { 
        		CvsLine line = (CvsLine)cell.getElement();
        		if(line.getLineNumber() == 1) {
        			cell.setBackground(Display.getCurrent().getSystemColor(SWT.COLOR_BLUE));
        			cell.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_WHITE));
        		} else {
        			cell.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_BLACK));
        		}
        		
        		cell.setText(String.valueOf(line.get(colNumber)));
        	}
        	
//            @Override
//            public String getText(Object element) {
//            	if(element instanceof CvsLine) {
//            		CvsLine line = (CvsLine)element;
//            		return line.get(colNumber);
//            	}
//            	return null;
//            }
        });
        
        return viewerColumn;
    }
}
