package com.logigear.rcp.app.item_editor.model;

public interface CvsLine {

	String get(int column);
	long getLineNumber();
}
