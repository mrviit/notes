package com.logigear.ta.resources;

import org.eclipse.swt.graphics.Image;

public interface IconService {
	
	Image getImage(Class<?> clazz) throws Exception;
	
	void registerImage(Class<?> clazz, Image image) throws Exception;

}
