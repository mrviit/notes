package com.logigear.ta.resources.interal;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.swt.graphics.Image;

import com.logigear.ta.core.model.internal.AbtActionImpl;
import com.logigear.ta.core.model.internal.ActionFolderImpl;
import com.logigear.ta.core.model.internal.ActionRootImpl;
import com.logigear.ta.core.model.internal.ArgumentImpl;
import com.logigear.ta.core.model.internal.DatasetRootImpl;
import com.logigear.ta.core.model.internal.InterfaceElementImpl;
import com.logigear.ta.core.model.internal.InterfaceEntityImpl;
import com.logigear.ta.core.model.internal.InterfaceFolderImpl;
import com.logigear.ta.core.model.internal.InterfaceRootImpl;
import com.logigear.ta.core.model.internal.ProjectImpl;
import com.logigear.ta.core.model.internal.TestCaseImpl;
import com.logigear.ta.core.model.internal.TestFolderImpl;
import com.logigear.ta.core.model.internal.TestModuleImpl;
import com.logigear.ta.core.model.internal.TestObjectiveImpl;
import com.logigear.ta.core.model.internal.TestRootImpl;
import com.logigear.ta.core.model.internal.TestStepImpl;
import com.logigear.ta.resources.IconService;
import com.logigear.ta.resources.icons.Icons;

public class IconServiceImpl implements IconService {
	
	Map<Object, Image> images;
	
	
	private void initialize() {
		images = new HashMap<>();
		try {
			images.put(ProjectImpl.class.getCanonicalName(), Icons.PROJECT.getImage());
			images.put(DatasetRootImpl.class.getCanonicalName(), Icons.DATA_ROOT.getImage());
			images.put(ActionRootImpl.class.getCanonicalName(), Icons.ACTION_ROOT.getImage());
			images.put(TestRootImpl.class.getCanonicalName(), Icons.TEST_ROOT.getImage());
			images.put(InterfaceRootImpl.class.getCanonicalName(), Icons.INTERACE_ROOT.getImage());
			
			images.put(ActionFolderImpl.class.getCanonicalName(), Icons.FOLDER.getImage());
			
			images.put(TestFolderImpl.class.getCanonicalName(), Icons.FOLDER.getImage());
			images.put(TestModuleImpl.class.getCanonicalName(), Icons.TEST_MODULE.getImage());
			images.put(TestObjectiveImpl.class.getCanonicalName(), Icons.TEST_OBJECTIVE.getImage());
			images.put(TestCaseImpl.class.getCanonicalName(), Icons.TEST_CASE.getImage());
			images.put(TestStepImpl.class.getCanonicalName(), Icons.TEST_STEP.getImage());
			
			images.put(AbtActionImpl.class.getCanonicalName(), Icons.ACTION.getImage());
			images.put(ArgumentImpl.class.getCanonicalName(), Icons.ARGUMENT.getImage());
			
			images.put(InterfaceFolderImpl.class.getCanonicalName(), Icons.INTERFACE.getImage());
			images.put(InterfaceEntityImpl.class.getCanonicalName(), Icons.INTERFACE_ENTITY.getImage());
			images.put(InterfaceElementImpl.class.getCanonicalName(), Icons.INTERFACE_ENTITY.getImage());
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	@Override
	public Image getImage(Class<?> clazz) {
		if(images == null) {
			initialize();
		}
		return images.get(clazz.getCanonicalName());
	}

	@Override
	public void registerImage(Class<?> clazz, Image image) {
		try {
			images.put(clazz.getCanonicalName(), image);
		} catch (Throwable e) {
			e.printStackTrace();
		}		
	}

	
}
