package com.logigear.ta.resources.icons;

import org.eclipse.swt.graphics.Image;

public enum Icons {
	
	LOGO(new Image(null, Icons.class.getResourceAsStream("testarchitect.gif"))),
	PROJECT(new Image(null, Icons.class.getResourceAsStream("testarchitect.gif"))),
	TEST_ROOT(new Image(null, Icons.class.getResourceAsStream("test_tree.gif"))),
	DATA_ROOT(new Image(null, Icons.class.getResourceAsStream("dataset_tree.gif"))),
	INTERACE_ROOT(new Image(null, Icons.class.getResourceAsStream("interface.gif"))),
	ACTION_ROOT(new Image(null, Icons.class.getResourceAsStream("action_tree.gif"))),
	
	FOLDER(new Image(null, Icons.class.getResourceAsStream("folder.gif"))),
	
	TEST_MODULE(new Image(null, Icons.class.getResourceAsStream("test_module_checked_in.gif"))),
	TEST_OBJECTIVE(new Image(null, Icons.class.getResourceAsStream("test_objective.gif"))),
	TEST_CASE(new Image(null, Icons.class.getResourceAsStream("test_case.gif"))),
	TEST_STEP(new Image(null, Icons.class.getResourceAsStream("test_step.png"))),
	
	ACTION(new Image(null, Icons.class.getResourceAsStream("action_checked_in.gif"))),
	ARGUMENT(new Image(null, Icons.class.getResourceAsStream("argument.gif"))),
	
	INTERFACE(new Image(null, Icons.class.getResourceAsStream("interface.gif"))),
	INTERFACE_ENTITY(new Image(null, Icons.class.getResourceAsStream("interface_entity_checked_in.gif"))),
	INTERFACE_ELEMENT(new Image(null, Icons.class.getResourceAsStream("interface_element.gif"))),
	;
	
	private Image image;

	private Icons(Image image) {
		this.image = image;
	}

	public Image getImage() {
		return image;
	}
}
