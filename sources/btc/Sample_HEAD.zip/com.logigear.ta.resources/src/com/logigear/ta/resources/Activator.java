package com.logigear.ta.resources;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import com.logigear.ta.resources.interal.IconServiceImpl;

public class Activator implements BundleActivator {
	
	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#start(org.osgi.framework.BundleContext)
	 */
	public void start(BundleContext bundleContext) throws Exception {
		bundleContext.registerService(IconService.class, new IconServiceImpl(), null);
	}

	/*
	 * (non-Javadoc)
	 * @see org.osgi.framework.BundleActivator#stop(org.osgi.framework.BundleContext)
	 */
	public void stop(BundleContext bundleContext) throws Exception {
		
	}

}
