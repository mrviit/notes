package com.logigear.ta.menu.extension.processor;

public class ToolbarProcessor {

}
