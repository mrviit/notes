package com.logigear.ta.menu.extension.handler;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.widgets.Shell;

public class TestHandler {

	@Execute
    public void execute(Shell shell) {
        MessageDialog.openInformation(shell, "Test", "Just testing");
    }
}
