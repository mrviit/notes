package com.logigear.ta.menu.extension.processor;

import java.util.List;

import javax.inject.Inject;
import javax.inject.Named;

import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.e4.ui.model.application.MApplication;
import org.eclipse.e4.ui.model.application.ui.menu.MHandledMenuItem;
import org.eclipse.e4.ui.model.application.ui.menu.MMenu;
import org.eclipse.e4.ui.model.application.ui.menu.MMenuElement;
import org.eclipse.e4.ui.model.application.ui.menu.MMenuFactory;
import org.eclipse.e4.ui.workbench.modeling.EModelService;

public class MenuProcessor {

	@Inject
	@Named("menu:org.eclipse.ui.main.menu")
	private MMenu menu;

	@Execute
	public void execute(MApplication app, EModelService modelService, IExtensionRegistry registery) {

		if (menu == null)
			return;

		List<MMenuElement> children = menu.getChildren();

		MHandledMenuItem menuItem = MMenuFactory.INSTANCE.createHandledMenuItem();
		menuItem.setLabel("Extensions");
		children.add(menuItem);

	}
}
