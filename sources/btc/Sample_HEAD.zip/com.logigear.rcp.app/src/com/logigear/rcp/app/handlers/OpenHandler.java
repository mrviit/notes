package com.logigear.rcp.app.handlers;

import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.inject.Inject;

import org.eclipse.e4.core.di.annotations.Execute;
import org.eclipse.e4.core.services.events.IEventBroker;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Shell;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.event.EventAdmin;

import com.logigear.rcp.app.common.EventsTopic;
public class OpenHandler {
	
	@Inject
	IEventBroker eventBroker;
	
	@Reference
    EventAdmin eventAdmin;
	
	@Execute
	public void execute(Shell shell) throws URISyntaxException{
		FileDialog dialog = new FileDialog(shell);
		String pathSelected = dialog.open();
		Path path = Paths.get(pathSelected	);
		eventBroker.send(EventsTopic.IMPORT_PROJECT, path);
		System.out.println("Send event 'ta/project/import' with Path object");
	}
}
