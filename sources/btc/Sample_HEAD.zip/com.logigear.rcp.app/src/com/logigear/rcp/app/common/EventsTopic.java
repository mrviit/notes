package com.logigear.rcp.app.common;

public interface EventsTopic {
	String OPEN_PROJECT_ITEM = "ta/project_explorer/open_item";
	String IMPORT_PROJECT = "ta/project/import";
}
