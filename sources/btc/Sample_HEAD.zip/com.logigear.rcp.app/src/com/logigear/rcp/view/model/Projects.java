package com.logigear.rcp.view.model;

import java.util.ArrayList;
import java.util.List;

import com.logigear.ta.core.model.Project;

public class Projects {
	private List<Project> projects = new ArrayList<>();
	
	public List<Project> getProjects(){
		return projects;
	}
	
	public void add(Project project) {
		projects.add(project);
	}
	
	public void remove(Project project) {
		projects.remove(project);
	}
	
	

}
