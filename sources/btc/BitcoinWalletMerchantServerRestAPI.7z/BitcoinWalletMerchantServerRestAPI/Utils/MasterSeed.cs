﻿using NBitcoin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BitcoinWalletMerchantServerRestAPI.Utils
{
    public sealed class MasterSeed
    {
        private static readonly Lazy<MasterSeed> _lazyInstance = new Lazy<MasterSeed>(() => new MasterSeed());

        //private static readonly Mnemonic _mnemo = new Mnemonic(Wordlist.English, WordCount.Twelve);
        private static readonly Mnemonic _mnemo = new Mnemonic(
            //"Some key work for mnemonic and the word could be 12 15 18 21 or 24 xxx yyy", 
            "various key word make this together number word must will twelve grant twenty one neglect twenty anxiety minute"
            , Wordlist.English);
        //private ExtKey _masterKey = null;
        private ExtKey masterPrivateKey = _mnemo.DeriveExtKey("my password");
        //private ExtKey masterPrivateKey = new ExtKey();
        //private ExtKey masterPrivateKey = ExtKey.Parse(
        //    "tprv8ZgxMBicQKsPeiBqP7FCvrq8tKFAjav9UbEyZ3hn521RNL3y7fsjbueoahVkzsdnmsA4TiEhKqNfLXm2TSKSmGd2MgQRJwjYarVeP71Uc9S");

        private ExtPubKey _neuterPubkey;

        static MasterSeed()
        {
            System.Diagnostics.Debug.WriteLine("mnemo: " + _mnemo);
            System.Diagnostics.Debug.WriteLine("MasterSeed TestNet: " 
                + Instance.masterPrivateKey.ToString(Network.TestNet));
        }

        public static MasterSeed Instance
        {
            get
            {
                return _lazyInstance.Value;
            }
        }

        private MasterSeed()
        {
            //You can go back from a Key to an ExtKey by supplying the Key and the ChainCode to the ExtKey constructor
            //Key key = _masterKey.PrivateKey;
            //byte[] chainCode = _masterKey.ChainCode;
            //_masterKey = new ExtKey(key, chainCode);
            
            _neuterPubkey = masterPrivateKey.Neuter();

            //System.Diagnostics.Debug.WriteLine("MasterSeed TestNet: " + Instance._masterKey.ToString(Network.TestNet));
        }

        public ExtPubKey Derive(String keyPath)
        {
            return _neuterPubkey.Derive(new KeyPath(keyPath));
        }

        public ExtPubKey GeneratePublicKey(uint orderId)
        {
            return _neuterPubkey.Derive(orderId);
        }
        public BitcoinSecret GeneratePrivateKey(uint orderId)
        {
            //Key key = masterPrivateKey.Derive(orderId).PrivateKey;
            //BitcoinSecret secret = key.GetBitcoinSecret(Network.Main);
            //Console.WriteLine(secret);
            return masterPrivateKey.Derive(orderId).PrivateKey.GetBitcoinSecret(BtcFacade.network);
        }
    }
}
