﻿using NBitcoin;
using NBitcoin.Payment;
using NBitcoin.RPC;
using NUnit.Framework;
using QBitNinja.Client;
using QBitNinja.Client.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace BitcoinWalletMerchantServerRestAPI.Utils
{
    public class PaymentServer : IDisposable
    {
        private static readonly Lazy<PaymentServer> _lazyInstance = new Lazy<PaymentServer>(() => new PaymentServer());

        public static PaymentServer Instance
        {
            get
            {
                return _lazyInstance.Value;
            }
        }

        HttpListener _Listener;
        Random rand = new Random();
        string _Prefix;
        private PaymentServer()
        {
            while (true)
            {
                try
                {
                    //_Prefix = "http://192.168.167.242:37391";// + rand.Next(2000, 50000) + "/";
                    _Prefix = "http://localhost:" + rand.Next(2000, 50000) + "/";
                    _Listener = new HttpListener();
                    _Listener.Prefixes.Add(_Prefix);
                    _Listener.Start();
                    _Listener.BeginGetContext(ListenerCallback, null);
                    break;
                }
                catch (HttpListenerException)
                {
                }
            }
        }

        void ListenerCallback(IAsyncResult ar)
        {
            try
            {
                var context = _Listener.EndGetContext(ar);
                var queryString = context.Request.QueryString;
                var type = queryString.Get("type");
                var orderId = int.Parse(context.Request.QueryString.Get("id"));
                var now = DateTimeOffset.UtcNow;
                var expire = now + TimeSpan.FromDays(1);
                TxOut txOut = new TxOut(Money.Satoshis(123), new BitcoinPubKeyAddress("mim5ukG6fbWn91dPiuyYPZLqB9pyQTbn61").ScriptPubKey);
                if (type == "Request")
                {
                    //Assert.Equal(PaymentRequest.MediaType, context.Request.AcceptTypes[0]);
                    context.Response.ContentType = PaymentRequest.MediaType;
                    PaymentRequest request = new PaymentRequest();
                    request.Details.Network = Network.TestNet;  //1
                    request.Details.Outputs.Add(new PaymentOutput(txOut)); //2
                    request.Details.Time = now; //3
                    request.Details.Expires = expire; //4
                    request.Details.Memo = "Paying for DHV ..."; //5
                    request.Details.PaymentUrl = new Uri(_Prefix + "?id=" + orderId + "&type=Payment"); //6
                    request.Details.MerchantData = BitConverter.GetBytes(orderId); //7

                    //request.Details.Outputs.Add(new PaymentOutput(new Money(0.0000124m, MoneyUnit.BTC), new BitcoinPubKeyAddress("mim5ukG6fbWn91dPiuyYPZLqB9pyQTbn61").ScriptPubKey)); //Destination 

                    //request.PKIType = PKIType.X509SHA256;
                    //request.PKIType = PKIType.None;
                    

                    //context.Response.ContentType = "application/bitcoin-paymentrequest";
                    //context.Response.Headers.AddOrReplace("Content-Transfer-Encoding", "binary");

                    //new X509Certificate2(Path, "", X509KeyStorageFlags.MachineKeySet);
                    //var cert = File.ReadAllBytes("data/DoHuuVi_Merchant_sha256.pfx"); //NicolasDorierMerchant, DoHuuVi_Merchant
                    //var cert = File.ReadAllBytes("data/NicolasDorierCA.pfx");
                    //request.Sign(cert, PKIType.X509SHA256);

                    //Assert.True(request.VerifySignature());
                    //Assert.True(request.VerifyChain());

                    request.WriteTo(context.Response.OutputStream);
                }
                else if (type == "Payment")
                {
                    
                    //After Initial Blockchain Downloading (IBD,) which can take days, start bitcoind. 
                    //Then use NBitcoin's RPCClient class to manage your wallet
                    //RPCClient clientx = new RPCClient(Network.TestNet);
                    //System.Diagnostics.Debug.WriteLine("clientx: " + clientx.GetNewAddress()); // Generate a new address
                    //System.Diagnostics.Debug.WriteLine(clientx.GetBalance()); // Get the balance


                    //Assert.Equal(PaymentMessage.MediaType, context.Request.ContentType);
                    //Assert.Equal(PaymentACK.MediaType, context.Request.AcceptTypes[0]);

                    var payment = PaymentMessage.Load(context.Request.InputStream);
                    //Assert.Equal(businessId, BitConverter.ToInt32(payment.MerchantData, 0));

                    var paymentTransaction = payment.Transactions.First();

                    System.Threading.Thread.Sleep(30000);

                    QBitNinjaClient client = new QBitNinjaClient(BtcFacade.network);
                    GetTransactionResponse transactionResponse = client.GetTransaction(paymentTransaction.GetHash()).Result;
                    var btcTransaction = transactionResponse.Transaction;
                    
                    var confirmations = transactionResponse.Block.Confirmations;

                    //var balance = client.GetBalance(new BitcoinPubKeyAddress(bitcoinPrivateKey.GetAddress().ToString())).Result;

                    //List<ICoin> receivedCoins = transactionResponse.ReceivedCoins;
                    //foreach (var coin in receivedCoins)
                    //{
                    //    Money amount = (Money)coin.Amount;

                    //    Console.WriteLine(amount.ToDecimal(MoneyUnit.BTC));
                    //    var paymentScript = coin.TxOut.ScriptPubKey;
                    //    Console.WriteLine(paymentScript);  // It's the ScriptPubKey
                    //    var address = paymentScript.GetDestinationAddress(Network.Main);
                    //    Console.WriteLine(address); // 1HfbwN6Lvma9eDsv7mdwp529tgiyfNr7jc
                    //    Console.WriteLine();
                    //}

                    ///
                    context.Response.ContentType = PaymentACK.MediaType;
                    var ack = payment.CreateACK();
                    //ack.Memo = "Your transaction: " + paymentTransaction.GetHash() + "\nConfirmations: " + confirmations;
                    ack.Memo = "Thanks for paying. Your transaction is being processed.";
                    ack.WriteTo(context.Response.OutputStream);
                }
                else
                    Assert.False(true, "Impossible");

                context.Response.Close();
                _Listener.BeginGetContext(ListenerCallback, null);
            }
            catch (Exception)
            {
                if (!_Stopped)
                    throw;
            }
        }
        public Uri GetPaymentRequestUri(long businessId)
        {
            BitcoinUrlBuilder builder = new BitcoinUrlBuilder()
            {
                PaymentRequestUrl = new Uri(_Prefix + "?id=" + businessId + "&type=Request")
            };
            return builder.Uri;
        }

        volatile bool _Stopped;

        #region IDisposable Members

        public void Dispose()
        {
            _Stopped = true;
            _Listener.Close();
        }

        #endregion
    }
}
