﻿using NBitcoin;
using NBitcoin.Payment;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace BitcoinWalletMerchantServerRestAPI.Utils
{
    public static class BtcFacade
    {
        public static readonly Network network = Network.TestNet;
        //private static RNGCryptoServiceProvider _rngCsp = new RNGCryptoServiceProvider();
        private static Random _random = new Random();
                
        public static String GenerateNewPublicAddress(long orderId)
        {
            return GenerateNewAddress(orderId).PubKey.GetAddress(network).ToString();
        }
    
        public static ExtPubKey GenerateNewAddress(long orderId)
        {
            return MasterSeed.Instance.GeneratePublicKey((uint)orderId);
        }
    }
}
