﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using BitcoinWalletMerchantServerRestAPI.Models;
using BitcoinWalletMerchantServerRestAPI.Utils;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Mvc;
using NBitcoin;
using NBitcoin.Payment;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BitcoinWalletMerchantServerRestAPI.Controllers
{
    [Route("api/payment/btc/[controller]")]
    public class InvoicesController : Controller
    {
        private readonly InvoicesContext _context;

        public InvoicesContext Context{
            get { return _context; }
        }

        public InvoicesController(InvoicesContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Invoice> GetAllInvoices()
        {
            return _context.Invoices.ToList();
        }

        //[HttpGet("{id}", Name = "GetNewInvoice")]
        //public IEnumerable<Invoice> GetNewInvoice(long id)
        //{
        //    return _context.Invoices.ToList();
        //}

        //[HttpGet("{id,type}", Name = "GetInvoice")]
        //public IActionResult FindById(long id)
        //{
        //    var item = _context.PaymentRequestInfos.FirstOrDefault(t => t.Id == id);
        //    if (item == null)
        //    {
        //        return NotFound();
        //    }
        //    return new ObjectResult(item);
        //}

        [HttpGet("{id}", Name = "GetInvoice")]
        public IActionResult GetById(long id)
        {
            var item = _context.PaymentRequestInfos.FirstOrDefault(t => t.Id == id);
            if (item == null)
            {
                return NotFound();
            }
            return new ObjectResult(item);
        }

        /// <summary>
        /// Creates a Invoice.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST /Invoice
        ///     {
        ///        "AmountMoney": "1"
        ///     }
        ///
        /// </remarks>
        /// <param AmountMoney="1"></param>
        /// <returns>A newly-created PaymentRequest</returns>
        /// <response code="201">Returns the newly-created PaymentRequest</response>
        /// <response code="400">If the item is null or invalid</response> 
        [HttpPost]
        [ProducesResponseType(typeof(PaymentRequestInfo), 201)]
        [ProducesResponseType(typeof(PaymentRequestInfo), 400)]
        public IActionResult Create([FromBody] Invoice item)
        {
            if (item == null)
            {
                return BadRequest();
            }

            _context.Invoices.Add(item);

            //var uri = BtcFacade.paymentServer.GetPaymentRequestUri(0);
            //BitcoinUrlBuilder btcUri = new BitcoinUrlBuilder(uri);
            //var request = btcUri.GetPaymentRequest();


            var paymentRequestInfo = new PaymentRequestInfo
            {
                Id = item.Id,
                AmountMoney = item.AmountMoney,
                BtcPublicAddress = BtcFacade.GenerateNewPublicAddress(item.Id),
                url = PaymentServer.Instance.GetPaymentRequestUri(item.Id).ToString()
                //url = "bitcoin:?r=" + Request.HttpContext.Connection.LocalIpAddress.ToString() + ":"
                //+ Request.HttpContext.Connection.LocalPort.ToString() + "?id=" + item.Id + "&type=Request"
                //url = GetPaymentRequestUri(item.Id).ToString()
            };
            _context.PaymentRequestInfos.Add(paymentRequestInfo);
            _context.SaveChanges();

            //return CreatedAtRoute(paymentRequestInfo);
            return CreatedAtRoute("GetInvoice", new { id = paymentRequestInfo.Id }, paymentRequestInfo);
        }

        [HttpPut("{id}")]
        public IActionResult Update(long id, [FromBody] Invoice item)
        {
            if (item == null || item.Id != id)
            {
                return BadRequest();
            }

            var invoice = _context.Invoices.FirstOrDefault(t => t.Id == id);
            if (invoice == null)
            {
                return NotFound();
            }

            //todo.Address = item.Address;
            //todo.AmountMoney = item.AmountMoney;
            //todo.Comment = item.Comment;
            //todo.CreateDate = item.CreateDate;

            _context.Invoices.Update(invoice);
            _context.SaveChanges();
            return new NoContentResult();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(long id)
        {
            var todo = _context.Invoices.FirstOrDefault(t => t.Id == id);
            if (todo == null)
            {
                return NotFound();
            }

            _context.Invoices.Remove(todo);
            _context.SaveChanges();
            return new NoContentResult();
        }

        private Uri GetPaymentRequestUri(long businessId)
        {
            IPAddress ip = Request.HttpContext.Connection.LocalIpAddress;
            int port = Request.HttpContext.Connection.LocalPort;
            BitcoinUrlBuilder builder = new BitcoinUrlBuilder()
            {
                PaymentRequestUrl = new Uri("http://" + ip.ToString() + ":" + port.ToString() + 
                "?id=" + businessId + "&type=Request")
            };
            return builder.Uri;
        }
    }
}
